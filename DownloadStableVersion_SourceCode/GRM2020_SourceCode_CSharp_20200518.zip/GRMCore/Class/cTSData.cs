﻿
namespace GRMCore
{
    public class cTSData
    {
        public struct TimeSeriesInfoInTSDB
        {
            public long TSID;
            public string StationName;
            public string HydroCode;
            public int MissingCount;
        }

    }
}
