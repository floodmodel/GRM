﻿
namespace GRMCore
{
    public struct sDomain
    {

        /// <summary>
        ///x방향 column 번호
        ///</summary>
        ///<remarks></remarks>
        public int XCol;
        /// <summary>
        ///y방향 row 번호
        ///</summary>
        ///<remarks></remarks>
        public int YRow;
    }
}
