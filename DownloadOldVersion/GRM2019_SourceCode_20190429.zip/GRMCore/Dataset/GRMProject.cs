﻿namespace GRMCore.Dataset
{


    partial class GRMProject
    {
        partial class ProjectSettingsDataTable
        {
        }
    }
}
