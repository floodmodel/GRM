﻿namespace GRMCore.Dataset
{


    partial class GRMProject
    {
        partial class RTenvDataTable
        {
        }

        partial class SubWatershedSettingsDataTable
        {
        }

        partial class ChannelSettingsDataTable
        {
        }

        partial class ProjectSettingsDataTable
        {
        }
    }
}
