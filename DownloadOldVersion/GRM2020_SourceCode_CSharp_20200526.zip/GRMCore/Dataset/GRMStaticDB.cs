﻿namespace GRMCore.Dataset
{


    partial class GRMStaticDB
    {
    }
}
