﻿Partial Class TimeSeriesDS
End Class
