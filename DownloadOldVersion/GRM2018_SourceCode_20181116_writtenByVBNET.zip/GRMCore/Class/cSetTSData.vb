﻿
Public Class cSetTSData
    Public Structure TimeSeriesInfoInTSDB
        Public TSID As Long
        Public StationName As String
        Public HydroCode As String
        Public MissingCount As Integer
    End Structure
End Class
