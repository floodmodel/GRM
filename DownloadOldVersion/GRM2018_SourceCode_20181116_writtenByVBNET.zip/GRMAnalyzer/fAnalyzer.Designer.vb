﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class fAnalyzer
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기에서는 수정하지 마세요.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ChartArea7 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend7 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series7 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(fAnalyzer))
        Me.Label87 = New System.Windows.Forms.Label()
        Me.pbFlow_200_300 = New System.Windows.Forms.PictureBox()
        Me.pbFLOWimg = New System.Windows.Forms.PictureBox()
        Me.btInitializeFlowRenderer = New System.Windows.Forms.Button()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.pbFlow_30000 = New System.Windows.Forms.PictureBox()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.pbRF010 = New System.Windows.Forms.PictureBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.pbRF000 = New System.Windows.Forms.PictureBox()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.pbRF002 = New System.Windows.Forms.PictureBox()
        Me.pbRF000to2 = New System.Windows.Forms.PictureBox()
        Me.pbRF005 = New System.Windows.Forms.PictureBox()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.pbRFimg = New System.Windows.Forms.PictureBox()
        Me.btInitializeRFrenderer = New System.Windows.Forms.Button()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.pbRF200 = New System.Windows.Forms.PictureBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.pbRF015 = New System.Windows.Forms.PictureBox()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.pbFlow_0_10 = New System.Windows.Forms.PictureBox()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.pbFlow_50_100 = New System.Windows.Forms.PictureBox()
        Me.pbFlow_10_50 = New System.Windows.Forms.PictureBox()
        Me.pbFlow_100_200 = New System.Windows.Forms.PictureBox()
        Me.pbFlow_300_400 = New System.Windows.Forms.PictureBox()
        Me.pbFlow_400_600 = New System.Windows.Forms.PictureBox()
        Me.pbFlow_600_800 = New System.Windows.Forms.PictureBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.pbRF020 = New System.Windows.Forms.PictureBox()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.pbRFAcc000 = New System.Windows.Forms.PictureBox()
        Me.pbRFACCimg = New System.Windows.Forms.PictureBox()
        Me.btInitializeRFAccRenderer = New System.Windows.Forms.Button()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.pbRFAcc500 = New System.Windows.Forms.PictureBox()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.pbRF025 = New System.Windows.Forms.PictureBox()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.tpSoilSaturation = New System.Windows.Forms.TabPage()
        Me.gbSoilSaturation = New System.Windows.Forms.GroupBox()
        Me.pbSSRimg = New System.Windows.Forms.PictureBox()
        Me.btInitializeSSRenderer = New System.Windows.Forms.Button()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.pb100 = New System.Windows.Forms.PictureBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.pb000 = New System.Windows.Forms.PictureBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.pb010 = New System.Windows.Forms.PictureBox()
        Me.pb005 = New System.Windows.Forms.PictureBox()
        Me.pb015 = New System.Windows.Forms.PictureBox()
        Me.pb020 = New System.Windows.Forms.PictureBox()
        Me.pb025 = New System.Windows.Forms.PictureBox()
        Me.pb030 = New System.Windows.Forms.PictureBox()
        Me.pb035 = New System.Windows.Forms.PictureBox()
        Me.pb040 = New System.Windows.Forms.PictureBox()
        Me.pb045 = New System.Windows.Forms.PictureBox()
        Me.pb050 = New System.Windows.Forms.PictureBox()
        Me.pb065 = New System.Windows.Forms.PictureBox()
        Me.pb055 = New System.Windows.Forms.PictureBox()
        Me.pb060 = New System.Windows.Forms.PictureBox()
        Me.pb070 = New System.Windows.Forms.PictureBox()
        Me.pb075 = New System.Windows.Forms.PictureBox()
        Me.pb095 = New System.Windows.Forms.PictureBox()
        Me.pb090 = New System.Windows.Forms.PictureBox()
        Me.pb085 = New System.Windows.Forms.PictureBox()
        Me.pb080 = New System.Windows.Forms.PictureBox()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.pbRF030 = New System.Windows.Forms.PictureBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.pbRFAcc000to5 = New System.Windows.Forms.PictureBox()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.pbRFAcc010 = New System.Windows.Forms.PictureBox()
        Me.pbRFAcc005 = New System.Windows.Forms.PictureBox()
        Me.pbRFAcc015 = New System.Windows.Forms.PictureBox()
        Me.pbRFAcc020 = New System.Windows.Forms.PictureBox()
        Me.pbRFAcc025 = New System.Windows.Forms.PictureBox()
        Me.pbRFAcc030 = New System.Windows.Forms.PictureBox()
        Me.pbRFAcc040 = New System.Windows.Forms.PictureBox()
        Me.pbRFAcc050 = New System.Windows.Forms.PictureBox()
        Me.pbRFAcc060 = New System.Windows.Forms.PictureBox()
        Me.pbRFAcc070 = New System.Windows.Forms.PictureBox()
        Me.pbRFAcc120 = New System.Windows.Forms.PictureBox()
        Me.pbRFAcc080 = New System.Windows.Forms.PictureBox()
        Me.pbRFAcc100 = New System.Windows.Forms.PictureBox()
        Me.pbRFAcc140 = New System.Windows.Forms.PictureBox()
        Me.pbRFAcc160 = New System.Windows.Forms.PictureBox()
        Me.pbRFAcc400 = New System.Windows.Forms.PictureBox()
        Me.pbRFAcc300 = New System.Windows.Forms.PictureBox()
        Me.pbRFAcc250 = New System.Windows.Forms.PictureBox()
        Me.pbRFAcc200 = New System.Windows.Forms.PictureBox()
        Me.pbRF035 = New System.Windows.Forms.PictureBox()
        Me.tbRFAcc = New System.Windows.Forms.TabPage()
        Me.pbRF040 = New System.Windows.Forms.PictureBox()
        Me.pbRF100 = New System.Windows.Forms.PictureBox()
        Me.pbRF045 = New System.Windows.Forms.PictureBox()
        Me.pbRF120 = New System.Windows.Forms.PictureBox()
        Me.pbRF050 = New System.Windows.Forms.PictureBox()
        Me.pbRF060 = New System.Windows.Forms.PictureBox()
        Me.pbRF080 = New System.Windows.Forms.PictureBox()
        Me.pbRF090 = New System.Windows.Forms.PictureBox()
        Me.pbRF160 = New System.Windows.Forms.PictureBox()
        Me.pbRF070 = New System.Windows.Forms.PictureBox()
        Me.pbRF140 = New System.Windows.Forms.PictureBox()
        Me.pbFlow_800_1000 = New System.Windows.Forms.PictureBox()
        Me.gbAnalzerSetObs = New System.Windows.Forms.GroupBox()
        Me.btOpenGMP = New System.Windows.Forms.Button()
        Me.tbGMPfpn = New System.Windows.Forms.TextBox()
        Me.chkLoadSimData = New System.Windows.Forms.CheckBox()
        Me.btSample = New System.Windows.Forms.Button()
        Me.tbFPNSimData = New System.Windows.Forms.TextBox()
        Me.btLoadSimData = New System.Windows.Forms.Button()
        Me.btLoadObsData = New System.Windows.Forms.Button()
        Me.tbFPNObsData = New System.Windows.Forms.TextBox()
        Me.btStartGRMorApplySettings = New System.Windows.Forms.Button()
        Me.tmAni = New System.Windows.Forms.Timer(Me.components)
        Me.tcDistribution = New System.Windows.Forms.TabControl()
        Me.tpFlow = New System.Windows.Forms.TabPage()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.pbFlow_1000_1500 = New System.Windows.Forms.PictureBox()
        Me.pbFlow_1500_2000 = New System.Windows.Forms.PictureBox()
        Me.pbFlow_2000_2500 = New System.Windows.Forms.PictureBox()
        Me.pbFlow_4000_5000 = New System.Windows.Forms.PictureBox()
        Me.pbFlow_2500_3000 = New System.Windows.Forms.PictureBox()
        Me.pbFlow_3000_4000 = New System.Windows.Forms.PictureBox()
        Me.pbFlow_5000_6000 = New System.Windows.Forms.PictureBox()
        Me.pbFlow_6000_8000 = New System.Windows.Forms.PictureBox()
        Me.pbFlow_20000_30000 = New System.Windows.Forms.PictureBox()
        Me.pbFlow_15000_20000 = New System.Windows.Forms.PictureBox()
        Me.pbFlow_10000_15000 = New System.Windows.Forms.PictureBox()
        Me.pbFlow_8000_10000 = New System.Windows.Forms.PictureBox()
        Me.tpRF = New System.Windows.Forms.TabPage()
        Me.gbRF = New System.Windows.Forms.GroupBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.dgvResults = New System.Windows.Forms.DataGridView()
        Me.gbHydrograph = New System.Windows.Forms.GroupBox()
        Me.Chart1 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.btTBrepeat = New System.Windows.Forms.Button()
        Me.btTBstart = New System.Windows.Forms.Button()
        Me.btTBStop = New System.Windows.Forms.Button()
        Me.btTBInitialize = New System.Windows.Forms.Button()
        Me.pbChartRF = New System.Windows.Forms.PictureBox()
        Me.tbChart = New System.Windows.Forms.TrackBar()
        Me.pbTrackBar = New System.Windows.Forms.PictureBox()
        Me.pbChartMain = New System.Windows.Forms.PictureBox()
        Me.pbChartContain = New System.Windows.Forms.PictureBox()
        Me.btStopSimulation = New System.Windows.Forms.Button()
        Me.btClose = New System.Windows.Forms.Button()
        CType(Me.pbFlow_200_300, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFLOWimg, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFlow_30000, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRF010, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRF000, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRF002, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRF000to2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRF005, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRFimg, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRF200, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRF015, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFlow_0_10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFlow_50_100, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFlow_10_50, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFlow_100_200, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFlow_300_400, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFlow_400_600, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFlow_600_800, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRF020, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRFAcc000, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRFACCimg, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRFAcc500, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRF025, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpSoilSaturation.SuspendLayout()
        Me.gbSoilSaturation.SuspendLayout()
        CType(Me.pbSSRimg, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb100, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb000, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb010, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb005, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb015, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb020, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb025, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb030, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb035, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb040, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb045, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb050, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb065, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb055, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb060, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb070, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb075, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb095, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb090, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb085, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb080, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRF030, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.pbRFAcc000to5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRFAcc010, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRFAcc005, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRFAcc015, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRFAcc020, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRFAcc025, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRFAcc030, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRFAcc040, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRFAcc050, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRFAcc060, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRFAcc070, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRFAcc120, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRFAcc080, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRFAcc100, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRFAcc140, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRFAcc160, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRFAcc400, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRFAcc300, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRFAcc250, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRFAcc200, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRF035, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tbRFAcc.SuspendLayout()
        CType(Me.pbRF040, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRF100, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRF045, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRF120, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRF050, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRF060, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRF080, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRF090, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRF160, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRF070, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbRF140, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFlow_800_1000, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbAnalzerSetObs.SuspendLayout()
        Me.tcDistribution.SuspendLayout()
        Me.tpFlow.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.pbFlow_1000_1500, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFlow_1500_2000, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFlow_2000_2500, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFlow_4000_5000, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFlow_2500_3000, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFlow_3000_4000, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFlow_5000_6000, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFlow_6000_8000, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFlow_20000_30000, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFlow_15000_20000, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFlow_10000_15000, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbFlow_8000_10000, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpRF.SuspendLayout()
        Me.gbRF.SuspendLayout()
        CType(Me.dgvResults, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbHydrograph.SuspendLayout()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbChartRF, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tbChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbTrackBar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbChartMain, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbChartContain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label87.Location = New System.Drawing.Point(451, 313)
        Me.Label87.Margin = New System.Windows.Forms.Padding(0)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(90, 12)
        Me.Label87.TabIndex = 5
        Me.Label87.Text = "  200 ≤ x < 300"
        Me.Label87.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pbFlow_200_300
        '
        Me.pbFlow_200_300.Location = New System.Drawing.Point(396, 313)
        Me.pbFlow_200_300.Margin = New System.Windows.Forms.Padding(2)
        Me.pbFlow_200_300.Name = "pbFlow_200_300"
        Me.pbFlow_200_300.Size = New System.Drawing.Size(50, 12)
        Me.pbFlow_200_300.TabIndex = 4
        Me.pbFlow_200_300.TabStop = False
        '
        'pbFLOWimg
        '
        Me.pbFLOWimg.BackColor = System.Drawing.Color.White
        Me.pbFLOWimg.Location = New System.Drawing.Point(10, 18)
        Me.pbFLOWimg.Name = "pbFLOWimg"
        Me.pbFLOWimg.Size = New System.Drawing.Size(370, 370)
        Me.pbFLOWimg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.pbFLOWimg.TabIndex = 0
        Me.pbFLOWimg.TabStop = False
        '
        'btInitializeFlowRenderer
        '
        Me.btInitializeFlowRenderer.Font = New System.Drawing.Font("굴림", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.btInitializeFlowRenderer.Location = New System.Drawing.Point(396, 16)
        Me.btInitializeFlowRenderer.Name = "btInitializeFlowRenderer"
        Me.btInitializeFlowRenderer.Size = New System.Drawing.Size(145, 22)
        Me.btInitializeFlowRenderer.TabIndex = 3
        Me.btInitializeFlowRenderer.Text = "Initialize renderer"
        Me.btInitializeFlowRenderer.UseVisualStyleBackColor = True
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label66.Location = New System.Drawing.Point(451, 41)
        Me.Label66.Margin = New System.Windows.Forms.Padding(2)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(60, 12)
        Me.Label66.TabIndex = 2
        Me.Label66.Text = "30000 ≤ x"
        Me.Label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label67.Location = New System.Drawing.Point(451, 377)
        Me.Label67.Margin = New System.Windows.Forms.Padding(0)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(80, 12)
        Me.Label67.TabIndex = 2
        Me.Label67.Text = "    0 ≤ x < 10"
        Me.Label67.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label68.Location = New System.Drawing.Point(451, 361)
        Me.Label68.Margin = New System.Windows.Forms.Padding(0)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(82, 12)
        Me.Label68.TabIndex = 2
        Me.Label68.Text = "   10 ≤ x < 50"
        Me.Label68.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pbFlow_30000
        '
        Me.pbFlow_30000.Location = New System.Drawing.Point(396, 41)
        Me.pbFlow_30000.Margin = New System.Windows.Forms.Padding(2)
        Me.pbFlow_30000.Name = "pbFlow_30000"
        Me.pbFlow_30000.Size = New System.Drawing.Size(50, 12)
        Me.pbFlow_30000.TabIndex = 1
        Me.pbFlow_30000.TabStop = False
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label69.Location = New System.Drawing.Point(451, 345)
        Me.Label69.Margin = New System.Windows.Forms.Padding(0)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(88, 12)
        Me.Label69.TabIndex = 2
        Me.Label69.Text = "   50 ≤ x < 100"
        Me.Label69.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label70.Location = New System.Drawing.Point(451, 329)
        Me.Label70.Margin = New System.Windows.Forms.Padding(0)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(90, 12)
        Me.Label70.TabIndex = 2
        Me.Label70.Text = "  100 ≤ x < 200"
        Me.Label70.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label71.Location = New System.Drawing.Point(451, 297)
        Me.Label71.Margin = New System.Windows.Forms.Padding(0)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(90, 12)
        Me.Label71.TabIndex = 2
        Me.Label71.Text = "  300 ≤ x < 400"
        Me.Label71.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label72
        '
        Me.Label72.AutoSize = True
        Me.Label72.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label72.Location = New System.Drawing.Point(451, 281)
        Me.Label72.Margin = New System.Windows.Forms.Padding(0)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(90, 12)
        Me.Label72.TabIndex = 2
        Me.Label72.Text = "  400 ≤ x < 600"
        Me.Label72.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label73.Location = New System.Drawing.Point(451, 265)
        Me.Label73.Margin = New System.Windows.Forms.Padding(0)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(90, 12)
        Me.Label73.TabIndex = 2
        Me.Label73.Text = "  600 ≤ x < 800"
        Me.Label73.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label74.Location = New System.Drawing.Point(451, 249)
        Me.Label74.Margin = New System.Windows.Forms.Padding(0)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(96, 12)
        Me.Label74.TabIndex = 2
        Me.Label74.Text = "  800 ≤ x < 1000"
        Me.Label74.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label75.Location = New System.Drawing.Point(451, 233)
        Me.Label75.Margin = New System.Windows.Forms.Padding(0)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(98, 12)
        Me.Label75.TabIndex = 2
        Me.Label75.Text = " 1000 ≤ x < 1500"
        Me.Label75.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label76.Location = New System.Drawing.Point(451, 217)
        Me.Label76.Margin = New System.Windows.Forms.Padding(0)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(98, 12)
        Me.Label76.TabIndex = 2
        Me.Label76.Text = " 1500 ≤ x < 2000"
        Me.Label76.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label77.Location = New System.Drawing.Point(451, 201)
        Me.Label77.Margin = New System.Windows.Forms.Padding(0)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(98, 12)
        Me.Label77.TabIndex = 2
        Me.Label77.Text = " 2000 ≤ x < 2500"
        Me.Label77.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label78.Location = New System.Drawing.Point(451, 185)
        Me.Label78.Margin = New System.Windows.Forms.Padding(0)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(98, 12)
        Me.Label78.TabIndex = 2
        Me.Label78.Text = " 2500 ≤ x < 3000"
        Me.Label78.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pbRF010
        '
        Me.pbRF010.Location = New System.Drawing.Point(399, 313)
        Me.pbRF010.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRF010.Name = "pbRF010"
        Me.pbRF010.Size = New System.Drawing.Size(50, 12)
        Me.pbRF010.TabIndex = 4
        Me.pbRF010.TabStop = False
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label34.Location = New System.Drawing.Point(454, 170)
        Me.Label34.Margin = New System.Windows.Forms.Padding(0)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(74, 12)
        Me.Label34.TabIndex = 2
        Me.Label34.Text = " 60 ≤ x < 70"
        Me.Label34.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label35.Location = New System.Drawing.Point(454, 138)
        Me.Label35.Margin = New System.Windows.Forms.Padding(0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(74, 12)
        Me.Label35.TabIndex = 2
        Me.Label35.Text = " 80 ≤ x < 90"
        Me.Label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label36.Location = New System.Drawing.Point(454, 154)
        Me.Label36.Margin = New System.Windows.Forms.Padding(0)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(74, 12)
        Me.Label36.TabIndex = 2
        Me.Label36.Text = " 70 ≤ x < 80"
        Me.Label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label37.Location = New System.Drawing.Point(454, 122)
        Me.Label37.Margin = New System.Windows.Forms.Padding(0)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(80, 12)
        Me.Label37.TabIndex = 2
        Me.Label37.Text = " 90 ≤ x < 100"
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label38.Location = New System.Drawing.Point(454, 106)
        Me.Label38.Margin = New System.Windows.Forms.Padding(0)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(82, 12)
        Me.Label38.TabIndex = 2
        Me.Label38.Text = "100 ≤ x < 120"
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pbRF000
        '
        Me.pbRF000.Location = New System.Drawing.Point(399, 377)
        Me.pbRF000.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRF000.Name = "pbRF000"
        Me.pbRF000.Size = New System.Drawing.Size(50, 12)
        Me.pbRF000.TabIndex = 1
        Me.pbRF000.TabStop = False
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label41.Location = New System.Drawing.Point(454, 74)
        Me.Label41.Margin = New System.Windows.Forms.Padding(0)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(82, 12)
        Me.Label41.TabIndex = 2
        Me.Label41.Text = "140 ≤ x < 160"
        Me.Label41.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label42.Location = New System.Drawing.Point(454, 90)
        Me.Label42.Margin = New System.Windows.Forms.Padding(0)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(82, 12)
        Me.Label42.TabIndex = 2
        Me.Label42.Text = "120 ≤ x < 140"
        Me.Label42.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pbRF002
        '
        Me.pbRF002.Location = New System.Drawing.Point(399, 345)
        Me.pbRF002.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRF002.Name = "pbRF002"
        Me.pbRF002.Size = New System.Drawing.Size(50, 12)
        Me.pbRF002.TabIndex = 1
        Me.pbRF002.TabStop = False
        '
        'pbRF000to2
        '
        Me.pbRF000to2.Location = New System.Drawing.Point(399, 361)
        Me.pbRF000to2.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRF000to2.Name = "pbRF000to2"
        Me.pbRF000to2.Size = New System.Drawing.Size(50, 12)
        Me.pbRF000to2.TabIndex = 1
        Me.pbRF000to2.TabStop = False
        '
        'pbRF005
        '
        Me.pbRF005.Location = New System.Drawing.Point(399, 329)
        Me.pbRF005.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRF005.Name = "pbRF005"
        Me.pbRF005.Size = New System.Drawing.Size(50, 12)
        Me.pbRF005.TabIndex = 1
        Me.pbRF005.TabStop = False
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label79.Location = New System.Drawing.Point(451, 153)
        Me.Label79.Margin = New System.Windows.Forms.Padding(0)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(98, 12)
        Me.Label79.TabIndex = 2
        Me.Label79.Text = " 4000 ≤ x < 5000"
        Me.Label79.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label64.Location = New System.Drawing.Point(454, 298)
        Me.Label64.Margin = New System.Windows.Forms.Padding(0)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(74, 12)
        Me.Label64.TabIndex = 5
        Me.Label64.Text = " 15 ≤ x < 20"
        Me.Label64.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pbRFimg
        '
        Me.pbRFimg.BackColor = System.Drawing.Color.White
        Me.pbRFimg.Location = New System.Drawing.Point(10, 18)
        Me.pbRFimg.Name = "pbRFimg"
        Me.pbRFimg.Size = New System.Drawing.Size(370, 370)
        Me.pbRFimg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.pbRFimg.TabIndex = 0
        Me.pbRFimg.TabStop = False
        '
        'btInitializeRFrenderer
        '
        Me.btInitializeRFrenderer.Font = New System.Drawing.Font("굴림", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.btInitializeRFrenderer.Location = New System.Drawing.Point(399, 16)
        Me.btInitializeRFrenderer.Name = "btInitializeRFrenderer"
        Me.btInitializeRFrenderer.Size = New System.Drawing.Size(145, 22)
        Me.btInitializeRFrenderer.TabIndex = 3
        Me.btInitializeRFrenderer.Text = "Initialize renderer"
        Me.btInitializeRFrenderer.UseVisualStyleBackColor = True
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label22.Location = New System.Drawing.Point(452, 42)
        Me.Label22.Margin = New System.Windows.Forms.Padding(2)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(90, 12)
        Me.Label22.TabIndex = 2
        Me.Label22.Text = "200 ≤ x  [mm]"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label23.Location = New System.Drawing.Point(454, 378)
        Me.Label23.Margin = New System.Windows.Forms.Padding(0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(44, 12)
        Me.Label23.TabIndex = 2
        Me.Label23.Text = "  0 = x "
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label24.Location = New System.Drawing.Point(454, 362)
        Me.Label24.Margin = New System.Windows.Forms.Padding(0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(64, 12)
        Me.Label24.TabIndex = 2
        Me.Label24.Text = "  0 < x < 2"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pbRF200
        '
        Me.pbRF200.Location = New System.Drawing.Point(399, 41)
        Me.pbRF200.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRF200.Name = "pbRF200"
        Me.pbRF200.Size = New System.Drawing.Size(50, 12)
        Me.pbRF200.TabIndex = 1
        Me.pbRF200.TabStop = False
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label25.Location = New System.Drawing.Point(454, 346)
        Me.Label25.Margin = New System.Windows.Forms.Padding(0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(66, 12)
        Me.Label25.TabIndex = 2
        Me.Label25.Text = "  2 ≤ x < 5"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label26.Location = New System.Drawing.Point(454, 330)
        Me.Label26.Margin = New System.Windows.Forms.Padding(0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(72, 12)
        Me.Label26.TabIndex = 2
        Me.Label26.Text = "  5 ≤ x < 10"
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label27.Location = New System.Drawing.Point(454, 282)
        Me.Label27.Margin = New System.Windows.Forms.Padding(0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(74, 12)
        Me.Label27.TabIndex = 2
        Me.Label27.Text = " 20 ≤ x < 25"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label28.Location = New System.Drawing.Point(454, 266)
        Me.Label28.Margin = New System.Windows.Forms.Padding(0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(74, 12)
        Me.Label28.TabIndex = 2
        Me.Label28.Text = " 25 ≤ x < 30"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label29.Location = New System.Drawing.Point(454, 250)
        Me.Label29.Margin = New System.Windows.Forms.Padding(0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(74, 12)
        Me.Label29.TabIndex = 2
        Me.Label29.Text = " 30 ≤ x < 35"
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label30.Location = New System.Drawing.Point(454, 234)
        Me.Label30.Margin = New System.Windows.Forms.Padding(0)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(74, 12)
        Me.Label30.TabIndex = 2
        Me.Label30.Text = " 35 ≤ x < 40"
        Me.Label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label31.Location = New System.Drawing.Point(454, 218)
        Me.Label31.Margin = New System.Windows.Forms.Padding(0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(74, 12)
        Me.Label31.TabIndex = 2
        Me.Label31.Text = " 40 ≤ x < 45"
        Me.Label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label32.Location = New System.Drawing.Point(454, 202)
        Me.Label32.Margin = New System.Windows.Forms.Padding(0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(74, 12)
        Me.Label32.TabIndex = 2
        Me.Label32.Text = " 45 ≤ x < 50"
        Me.Label32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pbRF015
        '
        Me.pbRF015.Location = New System.Drawing.Point(399, 297)
        Me.pbRF015.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRF015.Name = "pbRF015"
        Me.pbRF015.Size = New System.Drawing.Size(50, 12)
        Me.pbRF015.TabIndex = 1
        Me.pbRF015.TabStop = False
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label81.Location = New System.Drawing.Point(451, 137)
        Me.Label81.Margin = New System.Windows.Forms.Padding(0)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(98, 12)
        Me.Label81.TabIndex = 2
        Me.Label81.Text = " 5000 ≤ x < 6000"
        Me.Label81.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label82.Location = New System.Drawing.Point(451, 121)
        Me.Label82.Margin = New System.Windows.Forms.Padding(0)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(98, 12)
        Me.Label82.TabIndex = 2
        Me.Label82.Text = " 6000 ≤ x < 8000"
        Me.Label82.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pbFlow_0_10
        '
        Me.pbFlow_0_10.Location = New System.Drawing.Point(396, 377)
        Me.pbFlow_0_10.Margin = New System.Windows.Forms.Padding(2)
        Me.pbFlow_0_10.Name = "pbFlow_0_10"
        Me.pbFlow_0_10.Size = New System.Drawing.Size(50, 12)
        Me.pbFlow_0_10.TabIndex = 1
        Me.pbFlow_0_10.TabStop = False
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label83.Location = New System.Drawing.Point(451, 57)
        Me.Label83.Margin = New System.Windows.Forms.Padding(0)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(106, 12)
        Me.Label83.TabIndex = 2
        Me.Label83.Text = "20000 ≤ x < 30000"
        Me.Label83.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label84.Location = New System.Drawing.Point(451, 73)
        Me.Label84.Margin = New System.Windows.Forms.Padding(0)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(106, 12)
        Me.Label84.TabIndex = 2
        Me.Label84.Text = "15000 ≤ x < 20000"
        Me.Label84.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label85.Location = New System.Drawing.Point(451, 89)
        Me.Label85.Margin = New System.Windows.Forms.Padding(0)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(106, 12)
        Me.Label85.TabIndex = 2
        Me.Label85.Text = "10000 ≤ x < 15000"
        Me.Label85.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label86.Location = New System.Drawing.Point(451, 105)
        Me.Label86.Margin = New System.Windows.Forms.Padding(0)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(104, 12)
        Me.Label86.TabIndex = 2
        Me.Label86.Text = " 8000 ≤ x < 10000"
        Me.Label86.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pbFlow_50_100
        '
        Me.pbFlow_50_100.Location = New System.Drawing.Point(396, 345)
        Me.pbFlow_50_100.Margin = New System.Windows.Forms.Padding(2)
        Me.pbFlow_50_100.Name = "pbFlow_50_100"
        Me.pbFlow_50_100.Size = New System.Drawing.Size(50, 12)
        Me.pbFlow_50_100.TabIndex = 1
        Me.pbFlow_50_100.TabStop = False
        '
        'pbFlow_10_50
        '
        Me.pbFlow_10_50.Location = New System.Drawing.Point(396, 361)
        Me.pbFlow_10_50.Margin = New System.Windows.Forms.Padding(2)
        Me.pbFlow_10_50.Name = "pbFlow_10_50"
        Me.pbFlow_10_50.Size = New System.Drawing.Size(50, 12)
        Me.pbFlow_10_50.TabIndex = 1
        Me.pbFlow_10_50.TabStop = False
        '
        'pbFlow_100_200
        '
        Me.pbFlow_100_200.Location = New System.Drawing.Point(396, 329)
        Me.pbFlow_100_200.Margin = New System.Windows.Forms.Padding(2)
        Me.pbFlow_100_200.Name = "pbFlow_100_200"
        Me.pbFlow_100_200.Size = New System.Drawing.Size(50, 12)
        Me.pbFlow_100_200.TabIndex = 1
        Me.pbFlow_100_200.TabStop = False
        '
        'pbFlow_300_400
        '
        Me.pbFlow_300_400.Location = New System.Drawing.Point(396, 297)
        Me.pbFlow_300_400.Margin = New System.Windows.Forms.Padding(2)
        Me.pbFlow_300_400.Name = "pbFlow_300_400"
        Me.pbFlow_300_400.Size = New System.Drawing.Size(50, 12)
        Me.pbFlow_300_400.TabIndex = 1
        Me.pbFlow_300_400.TabStop = False
        '
        'pbFlow_400_600
        '
        Me.pbFlow_400_600.Location = New System.Drawing.Point(396, 281)
        Me.pbFlow_400_600.Margin = New System.Windows.Forms.Padding(2)
        Me.pbFlow_400_600.Name = "pbFlow_400_600"
        Me.pbFlow_400_600.Size = New System.Drawing.Size(50, 12)
        Me.pbFlow_400_600.TabIndex = 1
        Me.pbFlow_400_600.TabStop = False
        '
        'pbFlow_600_800
        '
        Me.pbFlow_600_800.Location = New System.Drawing.Point(396, 265)
        Me.pbFlow_600_800.Margin = New System.Windows.Forms.Padding(2)
        Me.pbFlow_600_800.Name = "pbFlow_600_800"
        Me.pbFlow_600_800.Size = New System.Drawing.Size(50, 12)
        Me.pbFlow_600_800.TabIndex = 1
        Me.pbFlow_600_800.TabStop = False
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label33.Location = New System.Drawing.Point(454, 186)
        Me.Label33.Margin = New System.Windows.Forms.Padding(0)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(74, 12)
        Me.Label33.TabIndex = 2
        Me.Label33.Text = " 50 ≤ x < 60"
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label80.Location = New System.Drawing.Point(451, 169)
        Me.Label80.Margin = New System.Windows.Forms.Padding(0)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(98, 12)
        Me.Label80.TabIndex = 2
        Me.Label80.Text = " 3000 ≤ x < 4000"
        Me.Label80.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pbRF020
        '
        Me.pbRF020.Location = New System.Drawing.Point(399, 281)
        Me.pbRF020.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRF020.Name = "pbRF020"
        Me.pbRF020.Size = New System.Drawing.Size(50, 12)
        Me.pbRF020.TabIndex = 1
        Me.pbRF020.TabStop = False
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label58.Location = New System.Drawing.Point(454, 90)
        Me.Label58.Margin = New System.Windows.Forms.Padding(0)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(82, 12)
        Me.Label58.TabIndex = 2
        Me.Label58.Text = "250 ≤ x < 300"
        Me.Label58.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label52.Location = New System.Drawing.Point(454, 74)
        Me.Label52.Margin = New System.Windows.Forms.Padding(0)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(82, 12)
        Me.Label52.TabIndex = 2
        Me.Label52.Text = "300 ≤ x < 400"
        Me.Label52.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label53.Location = New System.Drawing.Point(454, 58)
        Me.Label53.Margin = New System.Windows.Forms.Padding(0)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(82, 12)
        Me.Label53.TabIndex = 2
        Me.Label53.Text = "400 ≤ x < 500"
        Me.Label53.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label65.Location = New System.Drawing.Point(454, 378)
        Me.Label65.Margin = New System.Windows.Forms.Padding(0)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(44, 12)
        Me.Label65.TabIndex = 5
        Me.Label65.Text = "  0 = x "
        Me.Label65.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pbRFAcc000
        '
        Me.pbRFAcc000.Location = New System.Drawing.Point(399, 377)
        Me.pbRFAcc000.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRFAcc000.Name = "pbRFAcc000"
        Me.pbRFAcc000.Size = New System.Drawing.Size(50, 12)
        Me.pbRFAcc000.TabIndex = 4
        Me.pbRFAcc000.TabStop = False
        '
        'pbRFACCimg
        '
        Me.pbRFACCimg.BackColor = System.Drawing.Color.White
        Me.pbRFACCimg.Location = New System.Drawing.Point(10, 18)
        Me.pbRFACCimg.Name = "pbRFACCimg"
        Me.pbRFACCimg.Size = New System.Drawing.Size(370, 370)
        Me.pbRFACCimg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.pbRFACCimg.TabIndex = 0
        Me.pbRFACCimg.TabStop = False
        '
        'btInitializeRFAccRenderer
        '
        Me.btInitializeRFAccRenderer.Font = New System.Drawing.Font("굴림", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.btInitializeRFAccRenderer.Location = New System.Drawing.Point(399, 16)
        Me.btInitializeRFAccRenderer.Name = "btInitializeRFAccRenderer"
        Me.btInitializeRFAccRenderer.Size = New System.Drawing.Size(145, 22)
        Me.btInitializeRFAccRenderer.TabIndex = 3
        Me.btInitializeRFAccRenderer.Text = "Initialize renderer"
        Me.btInitializeRFAccRenderer.UseVisualStyleBackColor = True
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label43.Location = New System.Drawing.Point(452, 42)
        Me.Label43.Margin = New System.Windows.Forms.Padding(2)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(94, 12)
        Me.Label43.TabIndex = 2
        Me.Label43.Text = "500 ≤ x   [mm]"
        Me.Label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label44.Location = New System.Drawing.Point(454, 362)
        Me.Label44.Margin = New System.Windows.Forms.Padding(0)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(64, 12)
        Me.Label44.TabIndex = 2
        Me.Label44.Text = "  0 < x < 5"
        Me.Label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pbRFAcc500
        '
        Me.pbRFAcc500.Location = New System.Drawing.Point(399, 41)
        Me.pbRFAcc500.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRFAcc500.Name = "pbRFAcc500"
        Me.pbRFAcc500.Size = New System.Drawing.Size(50, 12)
        Me.pbRFAcc500.TabIndex = 1
        Me.pbRFAcc500.TabStop = False
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label46.Location = New System.Drawing.Point(454, 330)
        Me.Label46.Margin = New System.Windows.Forms.Padding(0)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(74, 12)
        Me.Label46.TabIndex = 2
        Me.Label46.Text = " 10 ≤ x < 15"
        Me.Label46.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label47.Location = New System.Drawing.Point(454, 314)
        Me.Label47.Margin = New System.Windows.Forms.Padding(0)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(74, 12)
        Me.Label47.TabIndex = 2
        Me.Label47.Text = " 15 ≤ x < 20"
        Me.Label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label48.Location = New System.Drawing.Point(454, 298)
        Me.Label48.Margin = New System.Windows.Forms.Padding(0)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(74, 12)
        Me.Label48.TabIndex = 2
        Me.Label48.Text = " 20 ≤ x < 25"
        Me.Label48.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label49.Location = New System.Drawing.Point(454, 282)
        Me.Label49.Margin = New System.Windows.Forms.Padding(0)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(74, 12)
        Me.Label49.TabIndex = 2
        Me.Label49.Text = " 25 ≤ x < 30"
        Me.Label49.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pbRF025
        '
        Me.pbRF025.Location = New System.Drawing.Point(399, 265)
        Me.pbRF025.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRF025.Name = "pbRF025"
        Me.pbRF025.Size = New System.Drawing.Size(50, 12)
        Me.pbRF025.TabIndex = 1
        Me.pbRF025.TabStop = False
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label45.Location = New System.Drawing.Point(454, 346)
        Me.Label45.Margin = New System.Windows.Forms.Padding(0)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(72, 12)
        Me.Label45.TabIndex = 2
        Me.Label45.Text = "  5 ≤ x < 10"
        Me.Label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'tpSoilSaturation
        '
        Me.tpSoilSaturation.Controls.Add(Me.gbSoilSaturation)
        Me.tpSoilSaturation.Location = New System.Drawing.Point(4, 22)
        Me.tpSoilSaturation.Name = "tpSoilSaturation"
        Me.tpSoilSaturation.Padding = New System.Windows.Forms.Padding(3)
        Me.tpSoilSaturation.Size = New System.Drawing.Size(575, 407)
        Me.tpSoilSaturation.TabIndex = 0
        Me.tpSoilSaturation.Text = "Soil saturation"
        Me.tpSoilSaturation.UseVisualStyleBackColor = True
        '
        'gbSoilSaturation
        '
        Me.gbSoilSaturation.BackColor = System.Drawing.SystemColors.Control
        Me.gbSoilSaturation.Controls.Add(Me.pbSSRimg)
        Me.gbSoilSaturation.Controls.Add(Me.btInitializeSSRenderer)
        Me.gbSoilSaturation.Controls.Add(Me.Label18)
        Me.gbSoilSaturation.Controls.Add(Me.Label11)
        Me.gbSoilSaturation.Controls.Add(Me.Label10)
        Me.gbSoilSaturation.Controls.Add(Me.pb100)
        Me.gbSoilSaturation.Controls.Add(Me.Label12)
        Me.gbSoilSaturation.Controls.Add(Me.Label9)
        Me.gbSoilSaturation.Controls.Add(Me.Label13)
        Me.gbSoilSaturation.Controls.Add(Me.Label1)
        Me.gbSoilSaturation.Controls.Add(Me.Label14)
        Me.gbSoilSaturation.Controls.Add(Me.Label8)
        Me.gbSoilSaturation.Controls.Add(Me.Label15)
        Me.gbSoilSaturation.Controls.Add(Me.Label16)
        Me.gbSoilSaturation.Controls.Add(Me.Label7)
        Me.gbSoilSaturation.Controls.Add(Me.Label6)
        Me.gbSoilSaturation.Controls.Add(Me.Label17)
        Me.gbSoilSaturation.Controls.Add(Me.Label5)
        Me.gbSoilSaturation.Controls.Add(Me.Label4)
        Me.gbSoilSaturation.Controls.Add(Me.Label3)
        Me.gbSoilSaturation.Controls.Add(Me.pb000)
        Me.gbSoilSaturation.Controls.Add(Me.Label21)
        Me.gbSoilSaturation.Controls.Add(Me.Label20)
        Me.gbSoilSaturation.Controls.Add(Me.Label19)
        Me.gbSoilSaturation.Controls.Add(Me.Label2)
        Me.gbSoilSaturation.Controls.Add(Me.pb010)
        Me.gbSoilSaturation.Controls.Add(Me.pb005)
        Me.gbSoilSaturation.Controls.Add(Me.pb015)
        Me.gbSoilSaturation.Controls.Add(Me.pb020)
        Me.gbSoilSaturation.Controls.Add(Me.pb025)
        Me.gbSoilSaturation.Controls.Add(Me.pb030)
        Me.gbSoilSaturation.Controls.Add(Me.pb035)
        Me.gbSoilSaturation.Controls.Add(Me.pb040)
        Me.gbSoilSaturation.Controls.Add(Me.pb045)
        Me.gbSoilSaturation.Controls.Add(Me.pb050)
        Me.gbSoilSaturation.Controls.Add(Me.pb065)
        Me.gbSoilSaturation.Controls.Add(Me.pb055)
        Me.gbSoilSaturation.Controls.Add(Me.pb060)
        Me.gbSoilSaturation.Controls.Add(Me.pb070)
        Me.gbSoilSaturation.Controls.Add(Me.pb075)
        Me.gbSoilSaturation.Controls.Add(Me.pb095)
        Me.gbSoilSaturation.Controls.Add(Me.pb090)
        Me.gbSoilSaturation.Controls.Add(Me.pb085)
        Me.gbSoilSaturation.Controls.Add(Me.pb080)
        Me.gbSoilSaturation.Location = New System.Drawing.Point(5, 3)
        Me.gbSoilSaturation.Name = "gbSoilSaturation"
        Me.gbSoilSaturation.Size = New System.Drawing.Size(565, 398)
        Me.gbSoilSaturation.TabIndex = 2
        Me.gbSoilSaturation.TabStop = False
        '
        'pbSSRimg
        '
        Me.pbSSRimg.BackColor = System.Drawing.Color.White
        Me.pbSSRimg.Location = New System.Drawing.Point(10, 18)
        Me.pbSSRimg.Name = "pbSSRimg"
        Me.pbSSRimg.Size = New System.Drawing.Size(370, 370)
        Me.pbSSRimg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.pbSSRimg.TabIndex = 0
        Me.pbSSRimg.TabStop = False
        '
        'btInitializeSSRenderer
        '
        Me.btInitializeSSRenderer.Font = New System.Drawing.Font("굴림", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.btInitializeSSRenderer.Location = New System.Drawing.Point(399, 16)
        Me.btInitializeSSRenderer.Name = "btInitializeSSRenderer"
        Me.btInitializeSSRenderer.Size = New System.Drawing.Size(145, 22)
        Me.btInitializeSSRenderer.TabIndex = 3
        Me.btInitializeSSRenderer.Text = "Initialize renderer"
        Me.btInitializeSSRenderer.UseVisualStyleBackColor = True
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label18.Location = New System.Drawing.Point(454, 50)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(58, 12)
        Me.Label18.TabIndex = 2
        Me.Label18.Text = "Saturated"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label11.Location = New System.Drawing.Point(454, 370)
        Me.Label11.Margin = New System.Windows.Forms.Padding(0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(90, 12)
        Me.Label11.TabIndex = 2
        Me.Label11.Text = "0.00 ≤ x < 0.05"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label10.Location = New System.Drawing.Point(454, 354)
        Me.Label10.Margin = New System.Windows.Forms.Padding(0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(90, 12)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "0.05 ≤ x < 0.10"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pb100
        '
        Me.pb100.Location = New System.Drawing.Point(399, 50)
        Me.pb100.Margin = New System.Windows.Forms.Padding(2)
        Me.pb100.Name = "pb100"
        Me.pb100.Size = New System.Drawing.Size(50, 12)
        Me.pb100.TabIndex = 1
        Me.pb100.TabStop = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label12.Location = New System.Drawing.Point(454, 338)
        Me.Label12.Margin = New System.Windows.Forms.Padding(0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(90, 12)
        Me.Label12.TabIndex = 2
        Me.Label12.Text = "0.10 ≤ x < 0.15"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label9.Location = New System.Drawing.Point(454, 322)
        Me.Label9.Margin = New System.Windows.Forms.Padding(0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(90, 12)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "0.15 ≤ x < 0.20"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label13.Location = New System.Drawing.Point(454, 306)
        Me.Label13.Margin = New System.Windows.Forms.Padding(0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(90, 12)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "0.20 ≤ x < 0.25"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label1.Location = New System.Drawing.Point(454, 290)
        Me.Label1.Margin = New System.Windows.Forms.Padding(0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(90, 12)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "0.25 ≤ x < 0.30"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label14.Location = New System.Drawing.Point(454, 274)
        Me.Label14.Margin = New System.Windows.Forms.Padding(0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(90, 12)
        Me.Label14.TabIndex = 2
        Me.Label14.Text = "0.30 ≤ x < 0.35"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label8.Location = New System.Drawing.Point(454, 258)
        Me.Label8.Margin = New System.Windows.Forms.Padding(0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(90, 12)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "0.35 ≤ x < 0.40"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label15.Location = New System.Drawing.Point(454, 242)
        Me.Label15.Margin = New System.Windows.Forms.Padding(0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(90, 12)
        Me.Label15.TabIndex = 2
        Me.Label15.Text = "0.40 ≤ x < 0.45"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label16.Location = New System.Drawing.Point(454, 226)
        Me.Label16.Margin = New System.Windows.Forms.Padding(0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(90, 12)
        Me.Label16.TabIndex = 2
        Me.Label16.Text = "0.45 ≤ x < 0.50"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label7.Location = New System.Drawing.Point(454, 210)
        Me.Label7.Margin = New System.Windows.Forms.Padding(0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(90, 12)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "0.50 ≤ x < 0.55"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label6.Location = New System.Drawing.Point(454, 194)
        Me.Label6.Margin = New System.Windows.Forms.Padding(0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(90, 12)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "0.55 ≤ x < 0.60"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label17.Location = New System.Drawing.Point(454, 162)
        Me.Label17.Margin = New System.Windows.Forms.Padding(0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(90, 12)
        Me.Label17.TabIndex = 2
        Me.Label17.Text = "0.65 ≤ x < 0.70"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label5.Location = New System.Drawing.Point(454, 178)
        Me.Label5.Margin = New System.Windows.Forms.Padding(0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(90, 12)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "0.60 ≤ x < 0.65"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label4.Location = New System.Drawing.Point(454, 146)
        Me.Label4.Margin = New System.Windows.Forms.Padding(0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(90, 12)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "0.70 ≤ x < 0.75"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label3.Location = New System.Drawing.Point(454, 130)
        Me.Label3.Margin = New System.Windows.Forms.Padding(0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(90, 12)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "0.75 ≤ x < 0.80"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pb000
        '
        Me.pb000.Location = New System.Drawing.Point(399, 370)
        Me.pb000.Margin = New System.Windows.Forms.Padding(2)
        Me.pb000.Name = "pb000"
        Me.pb000.Size = New System.Drawing.Size(50, 12)
        Me.pb000.TabIndex = 1
        Me.pb000.TabStop = False
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label21.Location = New System.Drawing.Point(454, 66)
        Me.Label21.Margin = New System.Windows.Forms.Padding(0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(90, 12)
        Me.Label21.TabIndex = 2
        Me.Label21.Text = "0.95 ≤ x < 1.00"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label20.Location = New System.Drawing.Point(454, 82)
        Me.Label20.Margin = New System.Windows.Forms.Padding(0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(90, 12)
        Me.Label20.TabIndex = 2
        Me.Label20.Text = "0.90 ≤ x < 0.95"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label19.Location = New System.Drawing.Point(454, 98)
        Me.Label19.Margin = New System.Windows.Forms.Padding(0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(90, 12)
        Me.Label19.TabIndex = 2
        Me.Label19.Text = "0.85 ≤ x < 0.90"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label2.Location = New System.Drawing.Point(454, 114)
        Me.Label2.Margin = New System.Windows.Forms.Padding(0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(90, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "0.80 ≤ x < 0.85"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pb010
        '
        Me.pb010.Location = New System.Drawing.Point(399, 338)
        Me.pb010.Margin = New System.Windows.Forms.Padding(2)
        Me.pb010.Name = "pb010"
        Me.pb010.Size = New System.Drawing.Size(50, 12)
        Me.pb010.TabIndex = 1
        Me.pb010.TabStop = False
        '
        'pb005
        '
        Me.pb005.Location = New System.Drawing.Point(399, 354)
        Me.pb005.Margin = New System.Windows.Forms.Padding(2)
        Me.pb005.Name = "pb005"
        Me.pb005.Size = New System.Drawing.Size(50, 12)
        Me.pb005.TabIndex = 1
        Me.pb005.TabStop = False
        '
        'pb015
        '
        Me.pb015.Location = New System.Drawing.Point(399, 322)
        Me.pb015.Margin = New System.Windows.Forms.Padding(2)
        Me.pb015.Name = "pb015"
        Me.pb015.Size = New System.Drawing.Size(50, 12)
        Me.pb015.TabIndex = 1
        Me.pb015.TabStop = False
        '
        'pb020
        '
        Me.pb020.Location = New System.Drawing.Point(399, 306)
        Me.pb020.Margin = New System.Windows.Forms.Padding(2)
        Me.pb020.Name = "pb020"
        Me.pb020.Size = New System.Drawing.Size(50, 12)
        Me.pb020.TabIndex = 1
        Me.pb020.TabStop = False
        '
        'pb025
        '
        Me.pb025.Location = New System.Drawing.Point(399, 290)
        Me.pb025.Margin = New System.Windows.Forms.Padding(2)
        Me.pb025.Name = "pb025"
        Me.pb025.Size = New System.Drawing.Size(50, 12)
        Me.pb025.TabIndex = 1
        Me.pb025.TabStop = False
        '
        'pb030
        '
        Me.pb030.Location = New System.Drawing.Point(399, 274)
        Me.pb030.Margin = New System.Windows.Forms.Padding(2)
        Me.pb030.Name = "pb030"
        Me.pb030.Size = New System.Drawing.Size(50, 12)
        Me.pb030.TabIndex = 1
        Me.pb030.TabStop = False
        '
        'pb035
        '
        Me.pb035.Location = New System.Drawing.Point(399, 258)
        Me.pb035.Margin = New System.Windows.Forms.Padding(2)
        Me.pb035.Name = "pb035"
        Me.pb035.Size = New System.Drawing.Size(50, 12)
        Me.pb035.TabIndex = 1
        Me.pb035.TabStop = False
        '
        'pb040
        '
        Me.pb040.Location = New System.Drawing.Point(399, 242)
        Me.pb040.Margin = New System.Windows.Forms.Padding(2)
        Me.pb040.Name = "pb040"
        Me.pb040.Size = New System.Drawing.Size(50, 12)
        Me.pb040.TabIndex = 1
        Me.pb040.TabStop = False
        '
        'pb045
        '
        Me.pb045.Location = New System.Drawing.Point(399, 226)
        Me.pb045.Margin = New System.Windows.Forms.Padding(2)
        Me.pb045.Name = "pb045"
        Me.pb045.Size = New System.Drawing.Size(50, 12)
        Me.pb045.TabIndex = 1
        Me.pb045.TabStop = False
        '
        'pb050
        '
        Me.pb050.Location = New System.Drawing.Point(399, 210)
        Me.pb050.Margin = New System.Windows.Forms.Padding(2)
        Me.pb050.Name = "pb050"
        Me.pb050.Size = New System.Drawing.Size(50, 12)
        Me.pb050.TabIndex = 1
        Me.pb050.TabStop = False
        '
        'pb065
        '
        Me.pb065.Location = New System.Drawing.Point(399, 162)
        Me.pb065.Margin = New System.Windows.Forms.Padding(2)
        Me.pb065.Name = "pb065"
        Me.pb065.Size = New System.Drawing.Size(50, 12)
        Me.pb065.TabIndex = 1
        Me.pb065.TabStop = False
        '
        'pb055
        '
        Me.pb055.Location = New System.Drawing.Point(399, 194)
        Me.pb055.Margin = New System.Windows.Forms.Padding(2)
        Me.pb055.Name = "pb055"
        Me.pb055.Size = New System.Drawing.Size(50, 12)
        Me.pb055.TabIndex = 1
        Me.pb055.TabStop = False
        '
        'pb060
        '
        Me.pb060.Location = New System.Drawing.Point(399, 178)
        Me.pb060.Margin = New System.Windows.Forms.Padding(2)
        Me.pb060.Name = "pb060"
        Me.pb060.Size = New System.Drawing.Size(50, 12)
        Me.pb060.TabIndex = 1
        Me.pb060.TabStop = False
        '
        'pb070
        '
        Me.pb070.Location = New System.Drawing.Point(399, 146)
        Me.pb070.Margin = New System.Windows.Forms.Padding(2)
        Me.pb070.Name = "pb070"
        Me.pb070.Size = New System.Drawing.Size(50, 12)
        Me.pb070.TabIndex = 1
        Me.pb070.TabStop = False
        '
        'pb075
        '
        Me.pb075.Location = New System.Drawing.Point(399, 130)
        Me.pb075.Margin = New System.Windows.Forms.Padding(2)
        Me.pb075.Name = "pb075"
        Me.pb075.Size = New System.Drawing.Size(50, 12)
        Me.pb075.TabIndex = 1
        Me.pb075.TabStop = False
        '
        'pb095
        '
        Me.pb095.Location = New System.Drawing.Point(399, 66)
        Me.pb095.Margin = New System.Windows.Forms.Padding(2)
        Me.pb095.Name = "pb095"
        Me.pb095.Size = New System.Drawing.Size(50, 12)
        Me.pb095.TabIndex = 1
        Me.pb095.TabStop = False
        '
        'pb090
        '
        Me.pb090.Location = New System.Drawing.Point(399, 82)
        Me.pb090.Margin = New System.Windows.Forms.Padding(2)
        Me.pb090.Name = "pb090"
        Me.pb090.Size = New System.Drawing.Size(50, 12)
        Me.pb090.TabIndex = 1
        Me.pb090.TabStop = False
        '
        'pb085
        '
        Me.pb085.Location = New System.Drawing.Point(399, 98)
        Me.pb085.Margin = New System.Windows.Forms.Padding(2)
        Me.pb085.Name = "pb085"
        Me.pb085.Size = New System.Drawing.Size(50, 12)
        Me.pb085.TabIndex = 1
        Me.pb085.TabStop = False
        '
        'pb080
        '
        Me.pb080.Location = New System.Drawing.Point(399, 114)
        Me.pb080.Margin = New System.Windows.Forms.Padding(2)
        Me.pb080.Name = "pb080"
        Me.pb080.Size = New System.Drawing.Size(50, 12)
        Me.pb080.TabIndex = 1
        Me.pb080.TabStop = False
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label50.Location = New System.Drawing.Point(454, 266)
        Me.Label50.Margin = New System.Windows.Forms.Padding(0)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(74, 12)
        Me.Label50.TabIndex = 2
        Me.Label50.Text = " 30 ≤ x < 40"
        Me.Label50.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pbRF030
        '
        Me.pbRF030.Location = New System.Drawing.Point(399, 249)
        Me.pbRF030.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRF030.Name = "pbRF030"
        Me.pbRF030.Size = New System.Drawing.Size(50, 12)
        Me.pbRF030.TabIndex = 1
        Me.pbRF030.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.Control
        Me.GroupBox1.Controls.Add(Me.Label58)
        Me.GroupBox1.Controls.Add(Me.Label52)
        Me.GroupBox1.Controls.Add(Me.Label53)
        Me.GroupBox1.Controls.Add(Me.Label65)
        Me.GroupBox1.Controls.Add(Me.pbRFAcc000)
        Me.GroupBox1.Controls.Add(Me.pbRFACCimg)
        Me.GroupBox1.Controls.Add(Me.btInitializeRFAccRenderer)
        Me.GroupBox1.Controls.Add(Me.Label43)
        Me.GroupBox1.Controls.Add(Me.Label44)
        Me.GroupBox1.Controls.Add(Me.Label45)
        Me.GroupBox1.Controls.Add(Me.pbRFAcc500)
        Me.GroupBox1.Controls.Add(Me.Label46)
        Me.GroupBox1.Controls.Add(Me.Label47)
        Me.GroupBox1.Controls.Add(Me.Label48)
        Me.GroupBox1.Controls.Add(Me.Label49)
        Me.GroupBox1.Controls.Add(Me.Label50)
        Me.GroupBox1.Controls.Add(Me.Label51)
        Me.GroupBox1.Controls.Add(Me.Label54)
        Me.GroupBox1.Controls.Add(Me.Label55)
        Me.GroupBox1.Controls.Add(Me.Label56)
        Me.GroupBox1.Controls.Add(Me.Label57)
        Me.GroupBox1.Controls.Add(Me.Label59)
        Me.GroupBox1.Controls.Add(Me.pbRFAcc000to5)
        Me.GroupBox1.Controls.Add(Me.Label60)
        Me.GroupBox1.Controls.Add(Me.Label61)
        Me.GroupBox1.Controls.Add(Me.Label62)
        Me.GroupBox1.Controls.Add(Me.Label63)
        Me.GroupBox1.Controls.Add(Me.pbRFAcc010)
        Me.GroupBox1.Controls.Add(Me.pbRFAcc005)
        Me.GroupBox1.Controls.Add(Me.pbRFAcc015)
        Me.GroupBox1.Controls.Add(Me.pbRFAcc020)
        Me.GroupBox1.Controls.Add(Me.pbRFAcc025)
        Me.GroupBox1.Controls.Add(Me.pbRFAcc030)
        Me.GroupBox1.Controls.Add(Me.pbRFAcc040)
        Me.GroupBox1.Controls.Add(Me.pbRFAcc050)
        Me.GroupBox1.Controls.Add(Me.pbRFAcc060)
        Me.GroupBox1.Controls.Add(Me.pbRFAcc070)
        Me.GroupBox1.Controls.Add(Me.pbRFAcc120)
        Me.GroupBox1.Controls.Add(Me.pbRFAcc080)
        Me.GroupBox1.Controls.Add(Me.pbRFAcc100)
        Me.GroupBox1.Controls.Add(Me.pbRFAcc140)
        Me.GroupBox1.Controls.Add(Me.pbRFAcc160)
        Me.GroupBox1.Controls.Add(Me.pbRFAcc400)
        Me.GroupBox1.Controls.Add(Me.pbRFAcc300)
        Me.GroupBox1.Controls.Add(Me.pbRFAcc250)
        Me.GroupBox1.Controls.Add(Me.pbRFAcc200)
        Me.GroupBox1.Location = New System.Drawing.Point(5, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(565, 398)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label51.Location = New System.Drawing.Point(454, 250)
        Me.Label51.Margin = New System.Windows.Forms.Padding(0)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(74, 12)
        Me.Label51.TabIndex = 2
        Me.Label51.Text = " 40 ≤ x < 50"
        Me.Label51.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label54.Location = New System.Drawing.Point(454, 234)
        Me.Label54.Margin = New System.Windows.Forms.Padding(0)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(74, 12)
        Me.Label54.TabIndex = 2
        Me.Label54.Text = " 50 ≤ x < 60"
        Me.Label54.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label55.Location = New System.Drawing.Point(454, 218)
        Me.Label55.Margin = New System.Windows.Forms.Padding(0)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(74, 12)
        Me.Label55.TabIndex = 2
        Me.Label55.Text = " 60 ≤ x < 70"
        Me.Label55.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label56.Location = New System.Drawing.Point(454, 186)
        Me.Label56.Margin = New System.Windows.Forms.Padding(0)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(80, 12)
        Me.Label56.TabIndex = 2
        Me.Label56.Text = " 80 ≤ x < 100"
        Me.Label56.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label57.Location = New System.Drawing.Point(454, 202)
        Me.Label57.Margin = New System.Windows.Forms.Padding(0)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(74, 12)
        Me.Label57.TabIndex = 2
        Me.Label57.Text = " 70 ≤ x < 80"
        Me.Label57.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label59.Location = New System.Drawing.Point(454, 170)
        Me.Label59.Margin = New System.Windows.Forms.Padding(0)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(82, 12)
        Me.Label59.TabIndex = 2
        Me.Label59.Text = "100 ≤ x < 120"
        Me.Label59.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pbRFAcc000to5
        '
        Me.pbRFAcc000to5.Location = New System.Drawing.Point(399, 361)
        Me.pbRFAcc000to5.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRFAcc000to5.Name = "pbRFAcc000to5"
        Me.pbRFAcc000to5.Size = New System.Drawing.Size(50, 12)
        Me.pbRFAcc000to5.TabIndex = 1
        Me.pbRFAcc000to5.TabStop = False
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label60.Location = New System.Drawing.Point(454, 106)
        Me.Label60.Margin = New System.Windows.Forms.Padding(0)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(82, 12)
        Me.Label60.TabIndex = 2
        Me.Label60.Text = "200 ≤ x < 250"
        Me.Label60.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label61.Location = New System.Drawing.Point(454, 122)
        Me.Label61.Margin = New System.Windows.Forms.Padding(0)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(82, 12)
        Me.Label61.TabIndex = 2
        Me.Label61.Text = "160 ≤ x < 200"
        Me.Label61.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label62.Location = New System.Drawing.Point(454, 138)
        Me.Label62.Margin = New System.Windows.Forms.Padding(0)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(82, 12)
        Me.Label62.TabIndex = 2
        Me.Label62.Text = "140 ≤ x < 160"
        Me.Label62.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label63.Location = New System.Drawing.Point(454, 154)
        Me.Label63.Margin = New System.Windows.Forms.Padding(0)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(82, 12)
        Me.Label63.TabIndex = 2
        Me.Label63.Text = "120 ≤ x < 140"
        Me.Label63.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pbRFAcc010
        '
        Me.pbRFAcc010.Location = New System.Drawing.Point(399, 329)
        Me.pbRFAcc010.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRFAcc010.Name = "pbRFAcc010"
        Me.pbRFAcc010.Size = New System.Drawing.Size(50, 12)
        Me.pbRFAcc010.TabIndex = 1
        Me.pbRFAcc010.TabStop = False
        '
        'pbRFAcc005
        '
        Me.pbRFAcc005.Location = New System.Drawing.Point(399, 345)
        Me.pbRFAcc005.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRFAcc005.Name = "pbRFAcc005"
        Me.pbRFAcc005.Size = New System.Drawing.Size(50, 12)
        Me.pbRFAcc005.TabIndex = 1
        Me.pbRFAcc005.TabStop = False
        '
        'pbRFAcc015
        '
        Me.pbRFAcc015.Location = New System.Drawing.Point(399, 313)
        Me.pbRFAcc015.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRFAcc015.Name = "pbRFAcc015"
        Me.pbRFAcc015.Size = New System.Drawing.Size(50, 12)
        Me.pbRFAcc015.TabIndex = 1
        Me.pbRFAcc015.TabStop = False
        '
        'pbRFAcc020
        '
        Me.pbRFAcc020.Location = New System.Drawing.Point(399, 297)
        Me.pbRFAcc020.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRFAcc020.Name = "pbRFAcc020"
        Me.pbRFAcc020.Size = New System.Drawing.Size(50, 12)
        Me.pbRFAcc020.TabIndex = 1
        Me.pbRFAcc020.TabStop = False
        '
        'pbRFAcc025
        '
        Me.pbRFAcc025.Location = New System.Drawing.Point(399, 281)
        Me.pbRFAcc025.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRFAcc025.Name = "pbRFAcc025"
        Me.pbRFAcc025.Size = New System.Drawing.Size(50, 12)
        Me.pbRFAcc025.TabIndex = 1
        Me.pbRFAcc025.TabStop = False
        '
        'pbRFAcc030
        '
        Me.pbRFAcc030.Location = New System.Drawing.Point(399, 265)
        Me.pbRFAcc030.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRFAcc030.Name = "pbRFAcc030"
        Me.pbRFAcc030.Size = New System.Drawing.Size(50, 12)
        Me.pbRFAcc030.TabIndex = 1
        Me.pbRFAcc030.TabStop = False
        '
        'pbRFAcc040
        '
        Me.pbRFAcc040.Location = New System.Drawing.Point(399, 249)
        Me.pbRFAcc040.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRFAcc040.Name = "pbRFAcc040"
        Me.pbRFAcc040.Size = New System.Drawing.Size(50, 12)
        Me.pbRFAcc040.TabIndex = 1
        Me.pbRFAcc040.TabStop = False
        '
        'pbRFAcc050
        '
        Me.pbRFAcc050.Location = New System.Drawing.Point(399, 233)
        Me.pbRFAcc050.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRFAcc050.Name = "pbRFAcc050"
        Me.pbRFAcc050.Size = New System.Drawing.Size(50, 12)
        Me.pbRFAcc050.TabIndex = 1
        Me.pbRFAcc050.TabStop = False
        '
        'pbRFAcc060
        '
        Me.pbRFAcc060.Location = New System.Drawing.Point(399, 217)
        Me.pbRFAcc060.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRFAcc060.Name = "pbRFAcc060"
        Me.pbRFAcc060.Size = New System.Drawing.Size(50, 12)
        Me.pbRFAcc060.TabIndex = 1
        Me.pbRFAcc060.TabStop = False
        '
        'pbRFAcc070
        '
        Me.pbRFAcc070.Location = New System.Drawing.Point(399, 201)
        Me.pbRFAcc070.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRFAcc070.Name = "pbRFAcc070"
        Me.pbRFAcc070.Size = New System.Drawing.Size(50, 12)
        Me.pbRFAcc070.TabIndex = 1
        Me.pbRFAcc070.TabStop = False
        '
        'pbRFAcc120
        '
        Me.pbRFAcc120.Location = New System.Drawing.Point(399, 153)
        Me.pbRFAcc120.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRFAcc120.Name = "pbRFAcc120"
        Me.pbRFAcc120.Size = New System.Drawing.Size(50, 12)
        Me.pbRFAcc120.TabIndex = 1
        Me.pbRFAcc120.TabStop = False
        '
        'pbRFAcc080
        '
        Me.pbRFAcc080.Location = New System.Drawing.Point(399, 185)
        Me.pbRFAcc080.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRFAcc080.Name = "pbRFAcc080"
        Me.pbRFAcc080.Size = New System.Drawing.Size(50, 12)
        Me.pbRFAcc080.TabIndex = 1
        Me.pbRFAcc080.TabStop = False
        '
        'pbRFAcc100
        '
        Me.pbRFAcc100.Location = New System.Drawing.Point(399, 169)
        Me.pbRFAcc100.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRFAcc100.Name = "pbRFAcc100"
        Me.pbRFAcc100.Size = New System.Drawing.Size(50, 12)
        Me.pbRFAcc100.TabIndex = 1
        Me.pbRFAcc100.TabStop = False
        '
        'pbRFAcc140
        '
        Me.pbRFAcc140.Location = New System.Drawing.Point(399, 137)
        Me.pbRFAcc140.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRFAcc140.Name = "pbRFAcc140"
        Me.pbRFAcc140.Size = New System.Drawing.Size(50, 12)
        Me.pbRFAcc140.TabIndex = 1
        Me.pbRFAcc140.TabStop = False
        '
        'pbRFAcc160
        '
        Me.pbRFAcc160.Location = New System.Drawing.Point(399, 121)
        Me.pbRFAcc160.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRFAcc160.Name = "pbRFAcc160"
        Me.pbRFAcc160.Size = New System.Drawing.Size(50, 12)
        Me.pbRFAcc160.TabIndex = 1
        Me.pbRFAcc160.TabStop = False
        '
        'pbRFAcc400
        '
        Me.pbRFAcc400.Location = New System.Drawing.Point(399, 57)
        Me.pbRFAcc400.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRFAcc400.Name = "pbRFAcc400"
        Me.pbRFAcc400.Size = New System.Drawing.Size(50, 12)
        Me.pbRFAcc400.TabIndex = 1
        Me.pbRFAcc400.TabStop = False
        '
        'pbRFAcc300
        '
        Me.pbRFAcc300.Location = New System.Drawing.Point(399, 73)
        Me.pbRFAcc300.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRFAcc300.Name = "pbRFAcc300"
        Me.pbRFAcc300.Size = New System.Drawing.Size(50, 12)
        Me.pbRFAcc300.TabIndex = 1
        Me.pbRFAcc300.TabStop = False
        '
        'pbRFAcc250
        '
        Me.pbRFAcc250.Location = New System.Drawing.Point(399, 89)
        Me.pbRFAcc250.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRFAcc250.Name = "pbRFAcc250"
        Me.pbRFAcc250.Size = New System.Drawing.Size(50, 12)
        Me.pbRFAcc250.TabIndex = 1
        Me.pbRFAcc250.TabStop = False
        '
        'pbRFAcc200
        '
        Me.pbRFAcc200.Location = New System.Drawing.Point(399, 105)
        Me.pbRFAcc200.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRFAcc200.Name = "pbRFAcc200"
        Me.pbRFAcc200.Size = New System.Drawing.Size(50, 12)
        Me.pbRFAcc200.TabIndex = 1
        Me.pbRFAcc200.TabStop = False
        '
        'pbRF035
        '
        Me.pbRF035.Location = New System.Drawing.Point(399, 233)
        Me.pbRF035.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRF035.Name = "pbRF035"
        Me.pbRF035.Size = New System.Drawing.Size(50, 12)
        Me.pbRF035.TabIndex = 1
        Me.pbRF035.TabStop = False
        '
        'tbRFAcc
        '
        Me.tbRFAcc.Controls.Add(Me.GroupBox1)
        Me.tbRFAcc.Location = New System.Drawing.Point(4, 22)
        Me.tbRFAcc.Name = "tbRFAcc"
        Me.tbRFAcc.Size = New System.Drawing.Size(575, 407)
        Me.tbRFAcc.TabIndex = 2
        Me.tbRFAcc.Text = "Cumulative precip."
        Me.tbRFAcc.UseVisualStyleBackColor = True
        '
        'pbRF040
        '
        Me.pbRF040.Location = New System.Drawing.Point(399, 217)
        Me.pbRF040.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRF040.Name = "pbRF040"
        Me.pbRF040.Size = New System.Drawing.Size(50, 12)
        Me.pbRF040.TabIndex = 1
        Me.pbRF040.TabStop = False
        '
        'pbRF100
        '
        Me.pbRF100.Location = New System.Drawing.Point(399, 105)
        Me.pbRF100.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRF100.Name = "pbRF100"
        Me.pbRF100.Size = New System.Drawing.Size(50, 12)
        Me.pbRF100.TabIndex = 1
        Me.pbRF100.TabStop = False
        '
        'pbRF045
        '
        Me.pbRF045.Location = New System.Drawing.Point(399, 201)
        Me.pbRF045.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRF045.Name = "pbRF045"
        Me.pbRF045.Size = New System.Drawing.Size(50, 12)
        Me.pbRF045.TabIndex = 1
        Me.pbRF045.TabStop = False
        '
        'pbRF120
        '
        Me.pbRF120.Location = New System.Drawing.Point(399, 89)
        Me.pbRF120.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRF120.Name = "pbRF120"
        Me.pbRF120.Size = New System.Drawing.Size(50, 12)
        Me.pbRF120.TabIndex = 1
        Me.pbRF120.TabStop = False
        '
        'pbRF050
        '
        Me.pbRF050.Location = New System.Drawing.Point(399, 185)
        Me.pbRF050.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRF050.Name = "pbRF050"
        Me.pbRF050.Size = New System.Drawing.Size(50, 12)
        Me.pbRF050.TabIndex = 1
        Me.pbRF050.TabStop = False
        '
        'pbRF060
        '
        Me.pbRF060.Location = New System.Drawing.Point(399, 169)
        Me.pbRF060.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRF060.Name = "pbRF060"
        Me.pbRF060.Size = New System.Drawing.Size(50, 12)
        Me.pbRF060.TabIndex = 1
        Me.pbRF060.TabStop = False
        '
        'pbRF080
        '
        Me.pbRF080.Location = New System.Drawing.Point(399, 137)
        Me.pbRF080.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRF080.Name = "pbRF080"
        Me.pbRF080.Size = New System.Drawing.Size(50, 12)
        Me.pbRF080.TabIndex = 1
        Me.pbRF080.TabStop = False
        '
        'pbRF090
        '
        Me.pbRF090.Location = New System.Drawing.Point(399, 121)
        Me.pbRF090.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRF090.Name = "pbRF090"
        Me.pbRF090.Size = New System.Drawing.Size(50, 12)
        Me.pbRF090.TabIndex = 1
        Me.pbRF090.TabStop = False
        '
        'pbRF160
        '
        Me.pbRF160.Location = New System.Drawing.Point(399, 57)
        Me.pbRF160.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRF160.Name = "pbRF160"
        Me.pbRF160.Size = New System.Drawing.Size(50, 12)
        Me.pbRF160.TabIndex = 1
        Me.pbRF160.TabStop = False
        '
        'pbRF070
        '
        Me.pbRF070.Location = New System.Drawing.Point(399, 153)
        Me.pbRF070.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRF070.Name = "pbRF070"
        Me.pbRF070.Size = New System.Drawing.Size(50, 12)
        Me.pbRF070.TabIndex = 1
        Me.pbRF070.TabStop = False
        '
        'pbRF140
        '
        Me.pbRF140.Location = New System.Drawing.Point(399, 73)
        Me.pbRF140.Margin = New System.Windows.Forms.Padding(2)
        Me.pbRF140.Name = "pbRF140"
        Me.pbRF140.Size = New System.Drawing.Size(50, 12)
        Me.pbRF140.TabIndex = 1
        Me.pbRF140.TabStop = False
        '
        'pbFlow_800_1000
        '
        Me.pbFlow_800_1000.Location = New System.Drawing.Point(396, 249)
        Me.pbFlow_800_1000.Margin = New System.Windows.Forms.Padding(2)
        Me.pbFlow_800_1000.Name = "pbFlow_800_1000"
        Me.pbFlow_800_1000.Size = New System.Drawing.Size(50, 12)
        Me.pbFlow_800_1000.TabIndex = 1
        Me.pbFlow_800_1000.TabStop = False
        '
        'gbAnalzerSetObs
        '
        Me.gbAnalzerSetObs.Controls.Add(Me.btOpenGMP)
        Me.gbAnalzerSetObs.Controls.Add(Me.tbGMPfpn)
        Me.gbAnalzerSetObs.Controls.Add(Me.chkLoadSimData)
        Me.gbAnalzerSetObs.Controls.Add(Me.btSample)
        Me.gbAnalzerSetObs.Controls.Add(Me.tbFPNSimData)
        Me.gbAnalzerSetObs.Controls.Add(Me.btLoadSimData)
        Me.gbAnalzerSetObs.Controls.Add(Me.btLoadObsData)
        Me.gbAnalzerSetObs.Controls.Add(Me.tbFPNObsData)
        Me.gbAnalzerSetObs.Location = New System.Drawing.Point(12, 12)
        Me.gbAnalzerSetObs.Name = "gbAnalzerSetObs"
        Me.gbAnalzerSetObs.Size = New System.Drawing.Size(367, 206)
        Me.gbAnalzerSetObs.TabIndex = 38
        Me.gbAnalzerSetObs.TabStop = False
        Me.gbAnalzerSetObs.Text = "Set files"
        '
        'btOpenGMP
        '
        Me.btOpenGMP.Location = New System.Drawing.Point(7, 29)
        Me.btOpenGMP.Name = "btOpenGMP"
        Me.btOpenGMP.Size = New System.Drawing.Size(109, 44)
        Me.btOpenGMP.TabIndex = 37
        Me.btOpenGMP.Text = "Open gmp file"
        Me.btOpenGMP.UseVisualStyleBackColor = True
        '
        'tbGMPfpn
        '
        Me.tbGMPfpn.Location = New System.Drawing.Point(121, 31)
        Me.tbGMPfpn.Multiline = True
        Me.tbGMPfpn.Name = "tbGMPfpn"
        Me.tbGMPfpn.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.tbGMPfpn.Size = New System.Drawing.Size(238, 43)
        Me.tbGMPfpn.TabIndex = 38
        '
        'chkLoadSimData
        '
        Me.chkLoadSimData.AutoSize = True
        Me.chkLoadSimData.Location = New System.Drawing.Point(7, 147)
        Me.chkLoadSimData.Name = "chkLoadSimData"
        Me.chkLoadSimData.Size = New System.Drawing.Size(109, 16)
        Me.chkLoadSimData.TabIndex = 36
        Me.chkLoadSimData.Text = "Load sim. data"
        Me.chkLoadSimData.UseVisualStyleBackColor = True
        '
        'btSample
        '
        Me.btSample.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btSample.Location = New System.Drawing.Point(7, 112)
        Me.btSample.Name = "btSample"
        Me.btSample.Size = New System.Drawing.Size(107, 20)
        Me.btSample.TabIndex = 34
        Me.btSample.Text = "Example"
        Me.btSample.UseVisualStyleBackColor = True
        '
        'tbFPNSimData
        '
        Me.tbFPNSimData.Enabled = False
        Me.tbFPNSimData.Location = New System.Drawing.Point(120, 146)
        Me.tbFPNSimData.Multiline = True
        Me.tbFPNSimData.Name = "tbFPNSimData"
        Me.tbFPNSimData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.tbFPNSimData.Size = New System.Drawing.Size(239, 43)
        Me.tbFPNSimData.TabIndex = 35
        '
        'btLoadSimData
        '
        Me.btLoadSimData.Enabled = False
        Me.btLoadSimData.Location = New System.Drawing.Point(7, 166)
        Me.btLoadSimData.Name = "btLoadSimData"
        Me.btLoadSimData.Size = New System.Drawing.Size(107, 23)
        Me.btLoadSimData.TabIndex = 34
        Me.btLoadSimData.Text = "Open sim. file"
        Me.btLoadSimData.UseVisualStyleBackColor = True
        '
        'btLoadObsData
        '
        Me.btLoadObsData.Location = New System.Drawing.Point(6, 87)
        Me.btLoadObsData.Name = "btLoadObsData"
        Me.btLoadObsData.Size = New System.Drawing.Size(109, 23)
        Me.btLoadObsData.TabIndex = 32
        Me.btLoadObsData.Text = "Open obs. file"
        Me.btLoadObsData.UseVisualStyleBackColor = True
        '
        'tbFPNObsData
        '
        Me.tbFPNObsData.Location = New System.Drawing.Point(120, 89)
        Me.tbFPNObsData.Multiline = True
        Me.tbFPNObsData.Name = "tbFPNObsData"
        Me.tbFPNObsData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.tbFPNObsData.Size = New System.Drawing.Size(239, 43)
        Me.tbFPNObsData.TabIndex = 33
        '
        'btStartGRMorApplySettings
        '
        Me.btStartGRMorApplySettings.Font = New System.Drawing.Font("굴림", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.btStartGRMorApplySettings.Location = New System.Drawing.Point(12, 231)
        Me.btStartGRMorApplySettings.Name = "btStartGRMorApplySettings"
        Me.btStartGRMorApplySettings.Size = New System.Drawing.Size(247, 51)
        Me.btStartGRMorApplySettings.TabIndex = 40
        Me.btStartGRMorApplySettings.Text = "Start simulation"
        Me.btStartGRMorApplySettings.UseVisualStyleBackColor = True
        '
        'tmAni
        '
        '
        'tcDistribution
        '
        Me.tcDistribution.Controls.Add(Me.tpFlow)
        Me.tcDistribution.Controls.Add(Me.tpRF)
        Me.tcDistribution.Controls.Add(Me.tbRFAcc)
        Me.tcDistribution.Controls.Add(Me.tpSoilSaturation)
        Me.tcDistribution.Location = New System.Drawing.Point(389, 396)
        Me.tcDistribution.Name = "tcDistribution"
        Me.tcDistribution.SelectedIndex = 0
        Me.tcDistribution.Size = New System.Drawing.Size(583, 433)
        Me.tcDistribution.TabIndex = 42
        '
        'tpFlow
        '
        Me.tpFlow.Controls.Add(Me.GroupBox2)
        Me.tpFlow.Location = New System.Drawing.Point(4, 22)
        Me.tpFlow.Name = "tpFlow"
        Me.tpFlow.Padding = New System.Windows.Forms.Padding(3)
        Me.tpFlow.Size = New System.Drawing.Size(575, 407)
        Me.tpFlow.TabIndex = 3
        Me.tpFlow.Text = "Flow"
        Me.tpFlow.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.SystemColors.Control
        Me.GroupBox2.Controls.Add(Me.Label87)
        Me.GroupBox2.Controls.Add(Me.pbFlow_200_300)
        Me.GroupBox2.Controls.Add(Me.pbFLOWimg)
        Me.GroupBox2.Controls.Add(Me.btInitializeFlowRenderer)
        Me.GroupBox2.Controls.Add(Me.Label66)
        Me.GroupBox2.Controls.Add(Me.Label67)
        Me.GroupBox2.Controls.Add(Me.Label68)
        Me.GroupBox2.Controls.Add(Me.pbFlow_30000)
        Me.GroupBox2.Controls.Add(Me.Label69)
        Me.GroupBox2.Controls.Add(Me.Label70)
        Me.GroupBox2.Controls.Add(Me.Label71)
        Me.GroupBox2.Controls.Add(Me.Label72)
        Me.GroupBox2.Controls.Add(Me.Label73)
        Me.GroupBox2.Controls.Add(Me.Label74)
        Me.GroupBox2.Controls.Add(Me.Label75)
        Me.GroupBox2.Controls.Add(Me.Label76)
        Me.GroupBox2.Controls.Add(Me.Label77)
        Me.GroupBox2.Controls.Add(Me.Label78)
        Me.GroupBox2.Controls.Add(Me.Label79)
        Me.GroupBox2.Controls.Add(Me.Label80)
        Me.GroupBox2.Controls.Add(Me.Label81)
        Me.GroupBox2.Controls.Add(Me.Label82)
        Me.GroupBox2.Controls.Add(Me.pbFlow_0_10)
        Me.GroupBox2.Controls.Add(Me.Label83)
        Me.GroupBox2.Controls.Add(Me.Label84)
        Me.GroupBox2.Controls.Add(Me.Label85)
        Me.GroupBox2.Controls.Add(Me.Label86)
        Me.GroupBox2.Controls.Add(Me.pbFlow_50_100)
        Me.GroupBox2.Controls.Add(Me.pbFlow_10_50)
        Me.GroupBox2.Controls.Add(Me.pbFlow_100_200)
        Me.GroupBox2.Controls.Add(Me.pbFlow_300_400)
        Me.GroupBox2.Controls.Add(Me.pbFlow_400_600)
        Me.GroupBox2.Controls.Add(Me.pbFlow_600_800)
        Me.GroupBox2.Controls.Add(Me.pbFlow_800_1000)
        Me.GroupBox2.Controls.Add(Me.pbFlow_1000_1500)
        Me.GroupBox2.Controls.Add(Me.pbFlow_1500_2000)
        Me.GroupBox2.Controls.Add(Me.pbFlow_2000_2500)
        Me.GroupBox2.Controls.Add(Me.pbFlow_4000_5000)
        Me.GroupBox2.Controls.Add(Me.pbFlow_2500_3000)
        Me.GroupBox2.Controls.Add(Me.pbFlow_3000_4000)
        Me.GroupBox2.Controls.Add(Me.pbFlow_5000_6000)
        Me.GroupBox2.Controls.Add(Me.pbFlow_6000_8000)
        Me.GroupBox2.Controls.Add(Me.pbFlow_20000_30000)
        Me.GroupBox2.Controls.Add(Me.pbFlow_15000_20000)
        Me.GroupBox2.Controls.Add(Me.pbFlow_10000_15000)
        Me.GroupBox2.Controls.Add(Me.pbFlow_8000_10000)
        Me.GroupBox2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.GroupBox2.Location = New System.Drawing.Point(5, 3)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(565, 398)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        '
        'pbFlow_1000_1500
        '
        Me.pbFlow_1000_1500.Location = New System.Drawing.Point(396, 233)
        Me.pbFlow_1000_1500.Margin = New System.Windows.Forms.Padding(2)
        Me.pbFlow_1000_1500.Name = "pbFlow_1000_1500"
        Me.pbFlow_1000_1500.Size = New System.Drawing.Size(50, 12)
        Me.pbFlow_1000_1500.TabIndex = 1
        Me.pbFlow_1000_1500.TabStop = False
        '
        'pbFlow_1500_2000
        '
        Me.pbFlow_1500_2000.Location = New System.Drawing.Point(396, 217)
        Me.pbFlow_1500_2000.Margin = New System.Windows.Forms.Padding(2)
        Me.pbFlow_1500_2000.Name = "pbFlow_1500_2000"
        Me.pbFlow_1500_2000.Size = New System.Drawing.Size(50, 12)
        Me.pbFlow_1500_2000.TabIndex = 1
        Me.pbFlow_1500_2000.TabStop = False
        '
        'pbFlow_2000_2500
        '
        Me.pbFlow_2000_2500.Location = New System.Drawing.Point(396, 201)
        Me.pbFlow_2000_2500.Margin = New System.Windows.Forms.Padding(2)
        Me.pbFlow_2000_2500.Name = "pbFlow_2000_2500"
        Me.pbFlow_2000_2500.Size = New System.Drawing.Size(50, 12)
        Me.pbFlow_2000_2500.TabIndex = 1
        Me.pbFlow_2000_2500.TabStop = False
        '
        'pbFlow_4000_5000
        '
        Me.pbFlow_4000_5000.Location = New System.Drawing.Point(396, 153)
        Me.pbFlow_4000_5000.Margin = New System.Windows.Forms.Padding(2)
        Me.pbFlow_4000_5000.Name = "pbFlow_4000_5000"
        Me.pbFlow_4000_5000.Size = New System.Drawing.Size(50, 12)
        Me.pbFlow_4000_5000.TabIndex = 1
        Me.pbFlow_4000_5000.TabStop = False
        '
        'pbFlow_2500_3000
        '
        Me.pbFlow_2500_3000.Location = New System.Drawing.Point(396, 185)
        Me.pbFlow_2500_3000.Margin = New System.Windows.Forms.Padding(2)
        Me.pbFlow_2500_3000.Name = "pbFlow_2500_3000"
        Me.pbFlow_2500_3000.Size = New System.Drawing.Size(50, 12)
        Me.pbFlow_2500_3000.TabIndex = 1
        Me.pbFlow_2500_3000.TabStop = False
        '
        'pbFlow_3000_4000
        '
        Me.pbFlow_3000_4000.Location = New System.Drawing.Point(396, 169)
        Me.pbFlow_3000_4000.Margin = New System.Windows.Forms.Padding(2)
        Me.pbFlow_3000_4000.Name = "pbFlow_3000_4000"
        Me.pbFlow_3000_4000.Size = New System.Drawing.Size(50, 12)
        Me.pbFlow_3000_4000.TabIndex = 1
        Me.pbFlow_3000_4000.TabStop = False
        '
        'pbFlow_5000_6000
        '
        Me.pbFlow_5000_6000.Location = New System.Drawing.Point(396, 137)
        Me.pbFlow_5000_6000.Margin = New System.Windows.Forms.Padding(2)
        Me.pbFlow_5000_6000.Name = "pbFlow_5000_6000"
        Me.pbFlow_5000_6000.Size = New System.Drawing.Size(50, 12)
        Me.pbFlow_5000_6000.TabIndex = 1
        Me.pbFlow_5000_6000.TabStop = False
        '
        'pbFlow_6000_8000
        '
        Me.pbFlow_6000_8000.Location = New System.Drawing.Point(396, 121)
        Me.pbFlow_6000_8000.Margin = New System.Windows.Forms.Padding(2)
        Me.pbFlow_6000_8000.Name = "pbFlow_6000_8000"
        Me.pbFlow_6000_8000.Size = New System.Drawing.Size(50, 12)
        Me.pbFlow_6000_8000.TabIndex = 1
        Me.pbFlow_6000_8000.TabStop = False
        '
        'pbFlow_20000_30000
        '
        Me.pbFlow_20000_30000.Location = New System.Drawing.Point(396, 57)
        Me.pbFlow_20000_30000.Margin = New System.Windows.Forms.Padding(2)
        Me.pbFlow_20000_30000.Name = "pbFlow_20000_30000"
        Me.pbFlow_20000_30000.Size = New System.Drawing.Size(50, 12)
        Me.pbFlow_20000_30000.TabIndex = 1
        Me.pbFlow_20000_30000.TabStop = False
        '
        'pbFlow_15000_20000
        '
        Me.pbFlow_15000_20000.Location = New System.Drawing.Point(396, 73)
        Me.pbFlow_15000_20000.Margin = New System.Windows.Forms.Padding(2)
        Me.pbFlow_15000_20000.Name = "pbFlow_15000_20000"
        Me.pbFlow_15000_20000.Size = New System.Drawing.Size(50, 12)
        Me.pbFlow_15000_20000.TabIndex = 1
        Me.pbFlow_15000_20000.TabStop = False
        '
        'pbFlow_10000_15000
        '
        Me.pbFlow_10000_15000.Location = New System.Drawing.Point(396, 89)
        Me.pbFlow_10000_15000.Margin = New System.Windows.Forms.Padding(2)
        Me.pbFlow_10000_15000.Name = "pbFlow_10000_15000"
        Me.pbFlow_10000_15000.Size = New System.Drawing.Size(50, 12)
        Me.pbFlow_10000_15000.TabIndex = 1
        Me.pbFlow_10000_15000.TabStop = False
        '
        'pbFlow_8000_10000
        '
        Me.pbFlow_8000_10000.Location = New System.Drawing.Point(396, 105)
        Me.pbFlow_8000_10000.Margin = New System.Windows.Forms.Padding(2)
        Me.pbFlow_8000_10000.Name = "pbFlow_8000_10000"
        Me.pbFlow_8000_10000.Size = New System.Drawing.Size(50, 12)
        Me.pbFlow_8000_10000.TabIndex = 1
        Me.pbFlow_8000_10000.TabStop = False
        '
        'tpRF
        '
        Me.tpRF.Controls.Add(Me.gbRF)
        Me.tpRF.Location = New System.Drawing.Point(4, 22)
        Me.tpRF.Name = "tpRF"
        Me.tpRF.Padding = New System.Windows.Forms.Padding(3)
        Me.tpRF.Size = New System.Drawing.Size(575, 407)
        Me.tpRF.TabIndex = 1
        Me.tpRF.Text = "Precipitation"
        Me.tpRF.UseVisualStyleBackColor = True
        '
        'gbRF
        '
        Me.gbRF.BackColor = System.Drawing.SystemColors.Control
        Me.gbRF.Controls.Add(Me.Label39)
        Me.gbRF.Controls.Add(Me.Label40)
        Me.gbRF.Controls.Add(Me.Label64)
        Me.gbRF.Controls.Add(Me.pbRF010)
        Me.gbRF.Controls.Add(Me.pbRFimg)
        Me.gbRF.Controls.Add(Me.btInitializeRFrenderer)
        Me.gbRF.Controls.Add(Me.Label22)
        Me.gbRF.Controls.Add(Me.Label23)
        Me.gbRF.Controls.Add(Me.Label24)
        Me.gbRF.Controls.Add(Me.pbRF200)
        Me.gbRF.Controls.Add(Me.Label25)
        Me.gbRF.Controls.Add(Me.Label26)
        Me.gbRF.Controls.Add(Me.Label27)
        Me.gbRF.Controls.Add(Me.Label28)
        Me.gbRF.Controls.Add(Me.Label29)
        Me.gbRF.Controls.Add(Me.Label30)
        Me.gbRF.Controls.Add(Me.Label31)
        Me.gbRF.Controls.Add(Me.Label32)
        Me.gbRF.Controls.Add(Me.Label33)
        Me.gbRF.Controls.Add(Me.Label34)
        Me.gbRF.Controls.Add(Me.Label35)
        Me.gbRF.Controls.Add(Me.Label36)
        Me.gbRF.Controls.Add(Me.Label37)
        Me.gbRF.Controls.Add(Me.Label38)
        Me.gbRF.Controls.Add(Me.pbRF000)
        Me.gbRF.Controls.Add(Me.Label41)
        Me.gbRF.Controls.Add(Me.Label42)
        Me.gbRF.Controls.Add(Me.pbRF002)
        Me.gbRF.Controls.Add(Me.pbRF000to2)
        Me.gbRF.Controls.Add(Me.pbRF005)
        Me.gbRF.Controls.Add(Me.pbRF015)
        Me.gbRF.Controls.Add(Me.pbRF020)
        Me.gbRF.Controls.Add(Me.pbRF025)
        Me.gbRF.Controls.Add(Me.pbRF030)
        Me.gbRF.Controls.Add(Me.pbRF035)
        Me.gbRF.Controls.Add(Me.pbRF040)
        Me.gbRF.Controls.Add(Me.pbRF045)
        Me.gbRF.Controls.Add(Me.pbRF070)
        Me.gbRF.Controls.Add(Me.pbRF050)
        Me.gbRF.Controls.Add(Me.pbRF060)
        Me.gbRF.Controls.Add(Me.pbRF080)
        Me.gbRF.Controls.Add(Me.pbRF090)
        Me.gbRF.Controls.Add(Me.pbRF160)
        Me.gbRF.Controls.Add(Me.pbRF140)
        Me.gbRF.Controls.Add(Me.pbRF120)
        Me.gbRF.Controls.Add(Me.pbRF100)
        Me.gbRF.Location = New System.Drawing.Point(5, 3)
        Me.gbRF.Name = "gbRF"
        Me.gbRF.Size = New System.Drawing.Size(565, 398)
        Me.gbRF.TabIndex = 3
        Me.gbRF.TabStop = False
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label39.Location = New System.Drawing.Point(454, 58)
        Me.Label39.Margin = New System.Windows.Forms.Padding(0)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(82, 12)
        Me.Label39.TabIndex = 2
        Me.Label39.Text = "160 ≤ x < 200"
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label40.Location = New System.Drawing.Point(454, 314)
        Me.Label40.Margin = New System.Windows.Forms.Padding(0)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(74, 12)
        Me.Label40.TabIndex = 2
        Me.Label40.Text = " 10 ≤ x < 15"
        Me.Label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'dgvResults
        '
        Me.dgvResults.AllowUserToAddRows = False
        Me.dgvResults.AllowUserToDeleteRows = False
        Me.dgvResults.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvResults.Location = New System.Drawing.Point(12, 291)
        Me.dgvResults.MultiSelect = False
        Me.dgvResults.Name = "dgvResults"
        Me.dgvResults.ReadOnly = True
        Me.dgvResults.RowHeadersWidth = 10
        Me.dgvResults.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.dgvResults.RowTemplate.Height = 23
        Me.dgvResults.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvResults.Size = New System.Drawing.Size(367, 538)
        Me.dgvResults.TabIndex = 41
        '
        'gbHydrograph
        '
        Me.gbHydrograph.Controls.Add(Me.Chart1)
        Me.gbHydrograph.Controls.Add(Me.btTBrepeat)
        Me.gbHydrograph.Controls.Add(Me.btTBstart)
        Me.gbHydrograph.Controls.Add(Me.btTBStop)
        Me.gbHydrograph.Controls.Add(Me.btTBInitialize)
        Me.gbHydrograph.Controls.Add(Me.pbChartRF)
        Me.gbHydrograph.Controls.Add(Me.tbChart)
        Me.gbHydrograph.Controls.Add(Me.pbTrackBar)
        Me.gbHydrograph.Controls.Add(Me.pbChartMain)
        Me.gbHydrograph.Controls.Add(Me.pbChartContain)
        Me.gbHydrograph.Location = New System.Drawing.Point(389, 12)
        Me.gbHydrograph.Name = "gbHydrograph"
        Me.gbHydrograph.Size = New System.Drawing.Size(583, 376)
        Me.gbHydrograph.TabIndex = 37
        Me.gbHydrograph.TabStop = False
        Me.gbHydrograph.Text = "Hydrograph"
        '
        'Chart1
        '
        ChartArea7.Name = "ChartArea1"
        Me.Chart1.ChartAreas.Add(ChartArea7)
        Legend7.Name = "Legend1"
        Me.Chart1.Legends.Add(Legend7)
        Me.Chart1.Location = New System.Drawing.Point(89, 238)
        Me.Chart1.Name = "Chart1"
        Series7.ChartArea = "ChartArea1"
        Series7.Legend = "Legend1"
        Series7.Name = "Series1"
        Me.Chart1.Series.Add(Series7)
        Me.Chart1.Size = New System.Drawing.Size(73, 73)
        Me.Chart1.TabIndex = 38
        Me.Chart1.Text = "Chart1"
        Me.Chart1.Visible = False
        '
        'btTBrepeat
        '
        Me.btTBrepeat.Image = CType(resources.GetObject("btTBrepeat.Image"), System.Drawing.Image)
        Me.btTBrepeat.Location = New System.Drawing.Point(547, 340)
        Me.btTBrepeat.Name = "btTBrepeat"
        Me.btTBrepeat.Size = New System.Drawing.Size(24, 24)
        Me.btTBrepeat.TabIndex = 37
        Me.btTBrepeat.UseVisualStyleBackColor = True
        '
        'btTBstart
        '
        Me.btTBstart.Font = New System.Drawing.Font("굴림", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.btTBstart.Location = New System.Drawing.Point(55, 343)
        Me.btTBstart.Name = "btTBstart"
        Me.btTBstart.Size = New System.Drawing.Size(20, 20)
        Me.btTBstart.TabIndex = 35
        Me.btTBstart.Text = "▶"
        Me.btTBstart.UseVisualStyleBackColor = True
        '
        'btTBStop
        '
        Me.btTBStop.Font = New System.Drawing.Font("굴림", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.btTBStop.Location = New System.Drawing.Point(35, 343)
        Me.btTBStop.Name = "btTBStop"
        Me.btTBStop.Size = New System.Drawing.Size(20, 20)
        Me.btTBStop.TabIndex = 34
        Me.btTBStop.Text = "∥"
        Me.btTBStop.UseVisualStyleBackColor = True
        '
        'btTBInitialize
        '
        Me.btTBInitialize.Font = New System.Drawing.Font("굴림", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.btTBInitialize.Location = New System.Drawing.Point(15, 343)
        Me.btTBInitialize.Name = "btTBInitialize"
        Me.btTBInitialize.Size = New System.Drawing.Size(20, 20)
        Me.btTBInitialize.TabIndex = 33
        Me.btTBInitialize.Text = "■"
        Me.btTBInitialize.UseVisualStyleBackColor = True
        '
        'pbChartRF
        '
        Me.pbChartRF.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.pbChartRF.Location = New System.Drawing.Point(10, 21)
        Me.pbChartRF.Name = "pbChartRF"
        Me.pbChartRF.Size = New System.Drawing.Size(564, 67)
        Me.pbChartRF.TabIndex = 32
        Me.pbChartRF.TabStop = False
        '
        'tbChart
        '
        Me.tbChart.AutoSize = False
        Me.tbChart.BackColor = System.Drawing.SystemColors.Control
        Me.tbChart.Location = New System.Drawing.Point(73, 343)
        Me.tbChart.Margin = New System.Windows.Forms.Padding(0)
        Me.tbChart.Maximum = 100
        Me.tbChart.Name = "tbChart"
        Me.tbChart.Size = New System.Drawing.Size(475, 26)
        Me.tbChart.TabIndex = 36
        Me.tbChart.TickFrequency = 0
        Me.tbChart.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'pbTrackBar
        '
        Me.pbTrackBar.Location = New System.Drawing.Point(10, 336)
        Me.pbTrackBar.Name = "pbTrackBar"
        Me.pbTrackBar.Size = New System.Drawing.Size(564, 34)
        Me.pbTrackBar.TabIndex = 37
        Me.pbTrackBar.TabStop = False
        '
        'pbChartMain
        '
        Me.pbChartMain.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.pbChartMain.Location = New System.Drawing.Point(10, 87)
        Me.pbChartMain.Name = "pbChartMain"
        Me.pbChartMain.Size = New System.Drawing.Size(564, 250)
        Me.pbChartMain.TabIndex = 31
        Me.pbChartMain.TabStop = False
        '
        'pbChartContain
        '
        Me.pbChartContain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pbChartContain.Location = New System.Drawing.Point(8, 20)
        Me.pbChartContain.Name = "pbChartContain"
        Me.pbChartContain.Size = New System.Drawing.Size(568, 350)
        Me.pbChartContain.TabIndex = 30
        Me.pbChartContain.TabStop = False
        '
        'btStopSimulation
        '
        Me.btStopSimulation.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btStopSimulation.Enabled = False
        Me.btStopSimulation.Location = New System.Drawing.Point(265, 231)
        Me.btStopSimulation.Name = "btStopSimulation"
        Me.btStopSimulation.Size = New System.Drawing.Size(114, 24)
        Me.btStopSimulation.TabIndex = 44
        Me.btStopSimulation.Text = "Stop simulation"
        Me.btStopSimulation.UseVisualStyleBackColor = True
        '
        'btClose
        '
        Me.btClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btClose.BackColor = System.Drawing.SystemColors.Control
        Me.btClose.Location = New System.Drawing.Point(265, 258)
        Me.btClose.Name = "btClose"
        Me.btClose.Size = New System.Drawing.Size(114, 24)
        Me.btClose.TabIndex = 45
        Me.btClose.Text = "Close"
        Me.btClose.UseVisualStyleBackColor = False
        '
        'fAnalyzer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(980, 837)
        Me.Controls.Add(Me.btStopSimulation)
        Me.Controls.Add(Me.btClose)
        Me.Controls.Add(Me.gbAnalzerSetObs)
        Me.Controls.Add(Me.btStartGRMorApplySettings)
        Me.Controls.Add(Me.tcDistribution)
        Me.Controls.Add(Me.dgvResults)
        Me.Controls.Add(Me.gbHydrograph)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(996, 875)
        Me.MinimumSize = New System.Drawing.Size(996, 875)
        Me.Name = "fAnalyzer"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.Text = "GRM analyzer"
        CType(Me.pbFlow_200_300, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFLOWimg, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFlow_30000, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRF010, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRF000, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRF002, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRF000to2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRF005, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRFimg, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRF200, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRF015, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFlow_0_10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFlow_50_100, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFlow_10_50, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFlow_100_200, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFlow_300_400, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFlow_400_600, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFlow_600_800, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRF020, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRFAcc000, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRFACCimg, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRFAcc500, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRF025, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpSoilSaturation.ResumeLayout(False)
        Me.gbSoilSaturation.ResumeLayout(False)
        Me.gbSoilSaturation.PerformLayout()
        CType(Me.pbSSRimg, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb100, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb000, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb010, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb005, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb015, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb020, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb025, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb030, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb035, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb040, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb045, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb050, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb065, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb055, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb060, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb070, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb075, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb095, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb090, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb085, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb080, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRF030, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.pbRFAcc000to5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRFAcc010, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRFAcc005, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRFAcc015, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRFAcc020, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRFAcc025, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRFAcc030, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRFAcc040, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRFAcc050, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRFAcc060, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRFAcc070, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRFAcc120, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRFAcc080, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRFAcc100, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRFAcc140, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRFAcc160, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRFAcc400, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRFAcc300, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRFAcc250, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRFAcc200, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRF035, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tbRFAcc.ResumeLayout(False)
        CType(Me.pbRF040, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRF100, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRF045, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRF120, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRF050, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRF060, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRF080, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRF090, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRF160, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRF070, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbRF140, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFlow_800_1000, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbAnalzerSetObs.ResumeLayout(False)
        Me.gbAnalzerSetObs.PerformLayout()
        Me.tcDistribution.ResumeLayout(False)
        Me.tpFlow.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.pbFlow_1000_1500, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFlow_1500_2000, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFlow_2000_2500, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFlow_4000_5000, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFlow_2500_3000, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFlow_3000_4000, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFlow_5000_6000, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFlow_6000_8000, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFlow_20000_30000, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFlow_15000_20000, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFlow_10000_15000, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbFlow_8000_10000, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpRF.ResumeLayout(False)
        Me.gbRF.ResumeLayout(False)
        Me.gbRF.PerformLayout()
        CType(Me.dgvResults, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbHydrograph.ResumeLayout(False)
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbChartRF, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tbChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbTrackBar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbChartMain, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbChartContain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Label87 As Label
    Friend WithEvents pbFlow_200_300 As PictureBox
    Friend WithEvents pbFLOWimg As PictureBox
    Friend WithEvents btInitializeFlowRenderer As Button
    Friend WithEvents Label66 As Label
    Friend WithEvents Label67 As Label
    Friend WithEvents Label68 As Label
    Friend WithEvents pbFlow_30000 As PictureBox
    Friend WithEvents Label69 As Label
    Friend WithEvents Label70 As Label
    Friend WithEvents Label71 As Label
    Friend WithEvents Label72 As Label
    Friend WithEvents Label73 As Label
    Friend WithEvents Label74 As Label
    Friend WithEvents Label75 As Label
    Friend WithEvents Label76 As Label
    Friend WithEvents Label77 As Label
    Friend WithEvents Label78 As Label
    Friend WithEvents pbRF010 As PictureBox
    Friend WithEvents Label34 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents pbRF000 As PictureBox
    Friend WithEvents Label41 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents pbRF002 As PictureBox
    Friend WithEvents pbRF000to2 As PictureBox
    Friend WithEvents pbRF005 As PictureBox
    Friend WithEvents Label79 As Label
    Friend WithEvents Label64 As Label
    Friend WithEvents pbRFimg As PictureBox
    Friend WithEvents btInitializeRFrenderer As Button
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents pbRF200 As PictureBox
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents pbRF015 As PictureBox
    Friend WithEvents Label81 As Label
    Friend WithEvents Label82 As Label
    Friend WithEvents pbFlow_0_10 As PictureBox
    Friend WithEvents Label83 As Label
    Friend WithEvents Label84 As Label
    Friend WithEvents Label85 As Label
    Friend WithEvents Label86 As Label
    Friend WithEvents pbFlow_50_100 As PictureBox
    Friend WithEvents pbFlow_10_50 As PictureBox
    Friend WithEvents pbFlow_100_200 As PictureBox
    Friend WithEvents pbFlow_300_400 As PictureBox
    Friend WithEvents pbFlow_400_600 As PictureBox
    Friend WithEvents pbFlow_600_800 As PictureBox
    Friend WithEvents Label33 As Label
    Friend WithEvents Label80 As Label
    Friend WithEvents pbRF020 As PictureBox
    Friend WithEvents Label58 As Label
    Friend WithEvents Label52 As Label
    Friend WithEvents Label53 As Label
    Friend WithEvents Label65 As Label
    Friend WithEvents pbRFAcc000 As PictureBox
    Friend WithEvents pbRFACCimg As PictureBox
    Friend WithEvents btInitializeRFAccRenderer As Button
    Friend WithEvents Label43 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents pbRFAcc500 As PictureBox
    Friend WithEvents Label46 As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents pbRF025 As PictureBox
    Friend WithEvents Label45 As Label
    Friend WithEvents tpSoilSaturation As TabPage
    Friend WithEvents gbSoilSaturation As GroupBox
    Friend WithEvents pbSSRimg As PictureBox
    Friend WithEvents btInitializeSSRenderer As Button
    Friend WithEvents Label18 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents pb100 As PictureBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents pb000 As PictureBox
    Friend WithEvents Label21 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents pb010 As PictureBox
    Friend WithEvents pb005 As PictureBox
    Friend WithEvents pb015 As PictureBox
    Friend WithEvents pb020 As PictureBox
    Friend WithEvents pb025 As PictureBox
    Friend WithEvents pb030 As PictureBox
    Friend WithEvents pb035 As PictureBox
    Friend WithEvents pb040 As PictureBox
    Friend WithEvents pb045 As PictureBox
    Friend WithEvents pb050 As PictureBox
    Friend WithEvents pb065 As PictureBox
    Friend WithEvents pb055 As PictureBox
    Friend WithEvents pb060 As PictureBox
    Friend WithEvents pb070 As PictureBox
    Friend WithEvents pb075 As PictureBox
    Friend WithEvents pb095 As PictureBox
    Friend WithEvents pb090 As PictureBox
    Friend WithEvents pb085 As PictureBox
    Friend WithEvents pb080 As PictureBox
    Friend WithEvents Label50 As Label
    Friend WithEvents pbRF030 As PictureBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label51 As Label
    Friend WithEvents Label54 As Label
    Friend WithEvents Label55 As Label
    Friend WithEvents Label56 As Label
    Friend WithEvents Label57 As Label
    Friend WithEvents Label59 As Label
    Friend WithEvents pbRFAcc000to5 As PictureBox
    Friend WithEvents Label60 As Label
    Friend WithEvents Label61 As Label
    Friend WithEvents Label62 As Label
    Friend WithEvents Label63 As Label
    Friend WithEvents pbRFAcc010 As PictureBox
    Friend WithEvents pbRFAcc005 As PictureBox
    Friend WithEvents pbRFAcc015 As PictureBox
    Friend WithEvents pbRFAcc020 As PictureBox
    Friend WithEvents pbRFAcc025 As PictureBox
    Friend WithEvents pbRFAcc030 As PictureBox
    Friend WithEvents pbRFAcc040 As PictureBox
    Friend WithEvents pbRFAcc050 As PictureBox
    Friend WithEvents pbRFAcc060 As PictureBox
    Friend WithEvents pbRFAcc070 As PictureBox
    Friend WithEvents pbRFAcc120 As PictureBox
    Friend WithEvents pbRFAcc080 As PictureBox
    Friend WithEvents pbRFAcc100 As PictureBox
    Friend WithEvents pbRFAcc140 As PictureBox
    Friend WithEvents pbRFAcc160 As PictureBox
    Friend WithEvents pbRFAcc400 As PictureBox
    Friend WithEvents pbRFAcc300 As PictureBox
    Friend WithEvents pbRFAcc250 As PictureBox
    Friend WithEvents pbRFAcc200 As PictureBox
    Friend WithEvents pbRF035 As PictureBox
    Friend WithEvents tbRFAcc As TabPage
    Friend WithEvents pbRF040 As PictureBox
    Friend WithEvents pbRF100 As PictureBox
    Friend WithEvents pbRF045 As PictureBox
    Friend WithEvents pbRF120 As PictureBox
    Friend WithEvents pbRF050 As PictureBox
    Friend WithEvents pbRF060 As PictureBox
    Friend WithEvents pbRF080 As PictureBox
    Friend WithEvents pbRF090 As PictureBox
    Friend WithEvents pbRF160 As PictureBox
    Friend WithEvents pbRF070 As PictureBox
    Friend WithEvents pbRF140 As PictureBox
    Friend WithEvents pbFlow_800_1000 As PictureBox
    Friend WithEvents gbAnalzerSetObs As GroupBox
    Friend WithEvents btSample As Button
    Friend WithEvents btLoadObsData As Button
    Friend WithEvents tbFPNObsData As TextBox
    Friend WithEvents btStartGRMorApplySettings As Button
    Friend WithEvents tmAni As Timer
    Friend WithEvents tcDistribution As TabControl
    Friend WithEvents tpFlow As TabPage
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents pbFlow_1000_1500 As PictureBox
    Friend WithEvents pbFlow_1500_2000 As PictureBox
    Friend WithEvents pbFlow_2000_2500 As PictureBox
    Friend WithEvents pbFlow_4000_5000 As PictureBox
    Friend WithEvents pbFlow_2500_3000 As PictureBox
    Friend WithEvents pbFlow_3000_4000 As PictureBox
    Friend WithEvents pbFlow_5000_6000 As PictureBox
    Friend WithEvents pbFlow_6000_8000 As PictureBox
    Friend WithEvents pbFlow_20000_30000 As PictureBox
    Friend WithEvents pbFlow_15000_20000 As PictureBox
    Friend WithEvents pbFlow_10000_15000 As PictureBox
    Friend WithEvents pbFlow_8000_10000 As PictureBox
    Friend WithEvents tpRF As TabPage
    Friend WithEvents gbRF As GroupBox
    Friend WithEvents Label39 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents dgvResults As DataGridView
    Friend WithEvents gbHydrograph As GroupBox
    Friend WithEvents btTBrepeat As Button
    Friend WithEvents btTBstart As Button
    Friend WithEvents btTBStop As Button
    Friend WithEvents btTBInitialize As Button
    Friend WithEvents pbChartRF As PictureBox
    Friend WithEvents tbChart As TrackBar
    Friend WithEvents pbTrackBar As PictureBox
    Friend WithEvents pbChartMain As PictureBox
    Friend WithEvents pbChartContain As PictureBox
    Friend WithEvents chkLoadSimData As CheckBox
    Friend WithEvents tbFPNSimData As TextBox
    Friend WithEvents btLoadSimData As Button
    Friend WithEvents Chart1 As DataVisualization.Charting.Chart
    Friend WithEvents btOpenGMP As Button
    Friend WithEvents tbGMPfpn As TextBox
    Friend WithEvents btStopSimulation As Button
    Friend WithEvents btClose As Button
End Class
