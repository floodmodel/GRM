﻿namespace GRMCore.Dataset
{


    partial class TimeSeriesDS
    {
    }
}
