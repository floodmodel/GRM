<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="2.18.13" minimumScale="inf" maximumScale="1e+08" hasScaleBasedVisibilityFlag="0">
  <pipe>
    <rasterrenderer opacity="1" alphaBand="0" classificationMax="2000" classificationMinMaxOrigin="User" band="1" classificationMin="1" type="singlebandpseudocolor">
      <rasterTransparency/>
      <rastershader>
        <colorrampshader colorRampType="INTERPOLATED" clip="0">
          <item alpha="255" value="1" label="1" color="#dcfff4"/>
          <item alpha="255" value="3.403" label="3.403" color="#ceffd3"/>
          <item alpha="255" value="56.26" label="56.26" color="#45850d"/>
          <item alpha="255" value="169.2" label="169.2" color="#bac27d"/>
          <item alpha="255" value="258.1" label="258.1" color="#dfc27d"/>
          <item alpha="255" value="522.4" label="522.4" color="#ca7520"/>
          <item alpha="255" value="1032" label="1032" color="#7d4813"/>
          <item alpha="255" value="1652" label="1652" color="#948e90"/>
          <item alpha="255" value="2000" label="2000" color="#ccc6c9"/>
        </colorrampshader>
      </rastershader>
    </rasterrenderer>
    <brightnesscontrast brightness="0" contrast="0"/>
    <huesaturation colorizeGreen="128" colorizeOn="0" colorizeRed="255" colorizeBlue="128" grayscaleMode="0" saturation="0" colorizeStrength="100"/>
    <rasterresampler maxOversampling="2"/>
  </pipe>
  <blendMode>0</blendMode>
</qgis>
