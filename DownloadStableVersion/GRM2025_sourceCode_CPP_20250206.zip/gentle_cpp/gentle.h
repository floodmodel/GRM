#pragma once
#include <iostream>
#include <stdio.h>
#include<string>
#include<sstream>
#include <map>
#include <filesystem>
//#include<ATLComTime.h> //MP �ּ�
#include <float.h>
#include <limits.h>
#include <omp.h>



#pragma comment(lib, "wbemuuid.lib")


#ifdef _WIN32

#include <comdef.h>
#include <Wbemidl.h>
//#include "bitmap_image.hpp"

#else


#endif 




using namespace std;
namespace fs = std::filesystem;

#define ERROR_NUMBER  -11223344
#define ENUM_TO_STR(ENUM) std::string(#ENUM)
const int CONST_BIG_SIZE_ARRAY_THRESHOLD = 200000000;


typedef struct _cpu_gpu_info
{
	string infoString="";
	int totalNumOfLP = 0;
} cpu_gpu_info;

typedef struct _ascRasterExtent
{
	double bottom=0.0;
	double top = 0.0;
	double left = 0.0;
	double right = 0.0;
	double extentWidth = 0.0;
	double extentHeight = 0.0;
} ascRasterExtent;

typedef struct _ascRasterHeader
{
	int nCols=0;
	int nRows = 0;
	double xllcorner = 0.0;
	double yllcorner = 0.0;
	float dx = 0.0;
	float dy = 0.0;
	float cellsize = 0.0;
	int nodataValue = 0;
	int headerEndingLineIndex = 0;
	int dataStartingLineIndex = 0;
} ascRasterHeader;

typedef struct _cellPosition
{
	int xCol = 0;
	int yRow = 0;
} cellPosition;

//typedef struct dateTime
//{
//	int year;
//	int month;
//	int day;
//	int hours;
//	int minutes;
//	int seconds;
//};


//typedef struct _CPUsInfo
//{
//	string infoString = "";
//	int numberOfCPUs = 0;
//	int totalNumOfLP = 0;
//} CPUsInfo;

typedef struct _version
{
	unsigned short pmajor = 0;  // MP ����. WORD -> unsigned short, NULL --> 0.
	unsigned short pminor = 0; 
	unsigned short pbuild = 0;
	unsigned short fmajor=0;
	unsigned short fminor = 0;
	unsigned short fbuild = 0;
	char LastWrittenTime[30] = { ""};
} version;


enum class weatherDataType
{
	None, 
	Mean,
	Mean_DividedArea,
	Raster_ASC,
	// =====��������� �ֽ�. �Ʒ��� ���� ������=============
	//NoneRF,	
	//MAP,	
	ASCraster_mmPhr
};


// 1:Discharge, 2:Depth, 3:WaterLevel, 4:None
enum class conditionDataType
{
	NoneCD,   //0
	Discharge, // 1
	Depth,      //2
	WaterLevel     //3
} ;

enum class fileOrConstant
{
	File,
	Constant,
	None
};

enum class rendererType
{
	Depth,
	Risk
};

enum class dateTimeFormat
{
	yyyymmdd__HHcolMMcolSS, // 20200324 15:30
	yyyy_mm_dd__HHcolMMcolSS, // 2020-03-24 15:30
	yyyymmddHHMMSS //202003241530
};

enum class timeUnitToShow
{
	toS, // �ʱ��� ǥ��
	toM, //�� ���� ǥ��
	toH, // �ð����� ǥ��
	toDay // �ϱ���
};



void appendTextToTextFile(string fpn, string textToAppend);


bool compareNaturalOrder(const std::string& a, const std::string& b);
int confirmDeleteFile(string filePathNames);
int confirmDeleteFiles(vector<string> filePathNames);

// formatted numeric string
string dtos(double value, int precision); //������
string dtos_L(double value, int length, int precision); //������

version getCurrentFileVersion();
string getCurrentExeFilePathName();
tm getCurrentTimeAsLocal_tm(); // MP �߰�
//int getDayOfYear(int year, int month, int day); // ������ �� ��° ������ ����ϴ� �Լ�
tm convertLocalTMtolTM(tm tm_in); // MP �߰�
tm convertTMtoLocalTM(tm tm_in); // MP �߰�
vector<string> getFileListInNaturalOrder(string path, string extension);
vector<string> getFileList(string path, string extension);

int getTableStateByXmlLineByLine(string aLine, string tableName);
int getTableStateByXmlLine(string aLine, string tableName);
int getVectorIndex(vector<int> inv, int value);
string getValueStringFromXmlLine(string aLine, string fieldName);

//bool isLeapYear(int year);//���⿩�� Ȯ��
bool isNumeric(string instr);
bool isNumericDbl(string instr);
bool isNumericInt(string instr);

vector<double> readTextFileToDoubleVector(string fpn);
vector<float> readTextFileToFloatVector(string fpn);
vector<string> readTextFileToStringVector(string fpn);
string readTextFileToString(string fpn);
map <int, vector<string>> readVatFile(string vatFPN, char seperator);
string replaceText(string inText, string textToFind, string textToRepalce);

tm secToHHMMSS(long sec);
tm stringToDateTime(string yyyymmddHHMM, bool asLocalTime);
tm stringToDateTime2(string yyyy_mm_dd__HHcolonMM, bool asLocalTime);
vector<double> splitToDoubleVector(string strToSplit, 
	const char delimeter, bool removeEmptyEntry = true);
vector<float> splitToFloatVector(string stringToBeSplitted, 
	char delimeter, bool removeEmptyEntry=true);
vector<double> splitToDoubleVector(string strToSplit,
	string delimeter, bool removeEmptyEntry = true);
vector<int> splitToIntVector(string stringToBeSplitted, 
	char delimeter, bool removeEmptyEntry = true);
vector<string> splitToStringVector(string stringToBeSplitted, 
	char delimeter, bool removeEmptyEntry = true);
string* splitToStringArray(string stringToBeSplitted,
	char delimeter, bool removeEmptyEntry = true);
char* stringToCharP(string inString);
char** stringVectorToCharPP(vector<string> inStrV);

std::tm timeDifferecceTM_DHMS(struct tm timePre_tm, struct tm timeAfter_tm); //MP �߰�
double timeDifferecceSEC(struct tm timePre_tm, struct tm timeAfter_tm);  //MP �߰�
// �� �Լ��� ����(����)�ð� ������ yyyymmddHHMM
string timeElaspedToDateTimeFormat(string startTime_yyyymmddHHMM,
	int elaspedTimeSec, timeUnitToShow unitToShow, 
	dateTimeFormat tformat);
// �� �Լ��� ����(����)�ð� ������ yyyy-mm-dd HH:MM
string timeElaspedToDateTimeFormat2(string startTime_yyyy_mm_dd__HHclnMM,
	int elaspedTimeSec, timeUnitToShow unitToShow, 
	dateTimeFormat tformat);
char* timeToString(struct tm* t, timeUnitToShow unitToShow,
	dateTimeFormat tformat, bool isLocalTime);
string timeToString(struct tm t, timeUnitToShow unitToShow, dateTimeFormat tformat);
//string timeToString(COleDateTime t, bool includeSEC, dateTimeFormat tformat);

string lower(string instring);
string upper(string instring);

void waitEnterKey();
//bool writeLog(const char* fpn, char* printText, int bprintFile, int bprintConsole); //MP �ּ�
bool writeLog(fs::path fpn, char* printText, int bprintFile, int bprintConsole);
bool writeLogString(fs::path fpn, string printText, int bprintFile, int bprintConsole);
//bool writeNewLog(const char* fpn, char* printText, int bprintFile, int bprintConsole); //MP �ּ�
//bool writeNewLog(fs::path fpn, char* printText, int bprintFile, int bprintConsole); //MP �ּ�
bool writeNewLogString(fs::path fpn, string printText, int bprintFile, int bprintConsole);
void writeTwoDimData(string fpn, double** array2D, int arrayLength_x, int arrayLength_y,
	int precision, int nodataValue);


#ifdef _WIN32
string BSTRtoString(BSTR inBSTR);
//cpuInfo getCPUinfoWIN();
cpu_gpu_info getCPUnGPU_infoInner(string target);

//string getGPUinfoWIN();


#else
cpu_gpu_info getCPUinfoLinux();

#endif 






class ascRasterFile
{
private:
	//const int BigSizeThreshold = 200000000;//2�ﰳ ����
	char separator = { ' ' };

public:
	bool disposed = false;
	string linesForHeader[8];
	ascRasterHeader header;
	string headerStringAll;
	double** valuesFromTL;
	ascRasterExtent extent;
	double value_max = DBL_MIN;
	double value_min = DBL_MAX;
	double value_sum = 0.0;
	int cellCount_notNull = 0;
	double value_ave = 0.0;

	ascRasterFile(string fpn_ascRasterFile);
	ascRasterHeader getAscRasterHeader(string LinesForHeader[], char separator);
	ascRasterExtent getAscRasterExtent(ascRasterHeader header);
	string makeHeaderString(int ncols, int nrows, double xll, double yll, double cellSize, double dx, double dy, int nodataValue);

	~ascRasterFile();
};

// ========== �������  inline �Լ� =========
//Comma�� �����ϴ� string ���ڸ� double�� ��ȯ
inline double stod_comma(string inst) {
	string tmp = replaceText(inst, ",", "");
	return(stod(tmp));
}

//Comma�� �����ϴ� string ���ڸ� integer�� ��ȯ
inline double stoi_comma(string inst) {
	string tmp = replaceText(inst, ",", "");
	return(stoi(tmp));
}

inline std::string trim(std::string& str)
{
	str.erase(0, str.find_first_not_of(' '));       //prefixing spaces
	str.erase(str.find_last_not_of(' ') + 1);         //surfixing spaces
	return str;
}

inline std::string trimL(std::string& str)
{
	str.erase(0, str.find_first_not_of(' '));       //prefixing spaces
	return str;
}


inline std::string trimR(std::string& str)
{
	str.erase(str.find_last_not_of(' ') + 1);         //surfixing spaces
	return str;
}

//2024.08.23. Linux ���� getline ��� \r ���ڰ� ���°�쿡 �� �Լ� ���
inline std::string eraseCR(std::string str)
{
	int position = str.find('\r');                          // \r�� ��ġ�� ã�´�.
	if (position != string::npos) str.erase(position);   // \r�� ã�Ҵٸ�, �� ��ġ�� ���ڸ� �����
	return str;
}


inline string getYYYYMMfromYYYYMMddHHmm
(string INPUTyyyyMMddHHmm)
{
	return INPUTyyyyMMddHHmm.substr(0, 6);
}

inline string getYYYYMMddHHfromYYYYMMddHHmm
(string INPUTyyyyMMddHHmm)
{
	return INPUTyyyyMMddHHmm.substr(0, 10);
}
// ==========  ������� inline �Լ� =========

// ======= ������� template ==========================
template <typename FLT_DBL> 
void makeASCTextFile(string fpn, string allHeader, 
	FLT_DBL array2D,
	int arrayLength_x, int arrayLength_y,
	int precision, int nodataValue){
	fs::path fpn_out = fs::path(fpn);
	std::ofstream outfile;
	outfile.open(fpn_out, ios::out);
	outfile << allHeader << "\n";
	int isBigSize = 0;
	//int BigSizeThreshold = 200000000; //2�ﰳ ����
	if (arrayLength_x * arrayLength_y > CONST_BIG_SIZE_ARRAY_THRESHOLD) { isBigSize = 1; }
	string formatString = "%." + to_string(precision) + "f ";
	const char* formatStr = formatString.c_str();
	//char* aaa= (char*)malloc(sizeof(char) * 10 * arrayLength_x + 1);
	if (isBigSize == 0) {
		string allLInes = "";
		for (int nr = 0; nr < arrayLength_y; nr++) {
			for (int nc = 0; nc < arrayLength_x; nc++) {
				char vchar[20];
				if (array2D[nc][nr] == nodataValue
					|| array2D[nc][nr] == 0) {
					sprintf(vchar, "%d ", (int)array2D[nc][nr]);
				}
				else {
					sprintf(vchar, formatStr, array2D[nc][nr]);
				}
				allLInes += vchar;
			}
			allLInes += '\n';
		}
		outfile << allLInes;
		outfile.close();
	}
	else {
		string lines = "";
		for (int nr = 0; nr < arrayLength_y; nr++) {
			for (int nc = 0; nc < arrayLength_x; nc++) {
				char s1[20];
				if (array2D[nc][nr] == nodataValue
					|| array2D[nc][nr] == 0) {
					sprintf(s1, "%d ", (int)array2D[nc][nr]);
				}
				else {
					sprintf(s1, formatStr, array2D[nc][nr]);
				}
				lines += s1;
			}
			lines += "\n";
			if (nr % 200 == 0) {
				outfile << lines;
				lines = "";
			}
		}
		outfile << lines;
		outfile.close();
	}
}

//#ifdef _WIN32

template <typename FLT_DBL, typename DBL_INT>
void makeBMPFileUsingArrayGTzero_InParallel(string imgFPNtoMake,
	FLT_DBL** array2D,
	int colxNum, int rowyNum, rendererType rt,
	FLT_DBL rendererMaxV = 0, DBL_INT nodataV = -9999) {
	int iw = colxNum;// *100;
	int ih = rowyNum;// *100;
	int numThread = 0;
	numThread = omp_get_max_threads();
	omp_set_num_threads(numThread);
	bitmap_image img(iw, ih);
	img.clear();
	image_drawer draw(img);
	if (rt == rendererType::Depth) {
#pragma omp parallel for 
		for (int y = 0; y < img.height(); ++y) {
			for (int x = 0; x < img.width(); ++x) {
				double av = array2D[x][y];
				if (av == nodataV) {
					av = 0;
				}
				else {
					if (av > rendererMaxV) {
						av = rendererMaxV;
					}
					if (av < 0) {
						av = 0;
					}
				}
				rgb_t col;
				if (av == 0) {
					col = { 255, 217, 170 };
				}
				else {
					int v = 490 + (int)(av / rendererMaxV * 500.0);// hsv_colormap ���� 490���� ���. 990���� ���
					col = hsv_colormap[v];
				}
				img.set_pixel(x, y, col.red, col.green, col.blue);
			}
		}
	}
	else if (rt == rendererType::Risk) {
#pragma omp parallel for 
		for (int y = 0; y < img.height(); ++y) {
			for (int x = 0; x < img.width(); ++x) {
				double av = array2D[x][y];
				rgb_t col;
				if (av == nodataV) {
					col = { 255, 255, 255 };
				}
				else {
					if (av > rendererMaxV) {
						av = rendererMaxV;
					}
					if (av < 0) {
						av = 0;
					}
					int v = 380 + (int)(av / rendererMaxV * 610.0);// hsv_colormap ���� 380���� ���. 990���� ���
					col = hsv_colormap[v];
				}
				img.set_pixel(x, y, col.red, col.green, col.blue);
			}
		}
	}
	img.save_image(imgFPNtoMake);
}
//#else


//#endif 
// ======= ������� template ==========================
