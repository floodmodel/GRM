<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis styleCategories="Symbology|Symbology3D|Labeling|Fields|Forms|Actions|Diagrams|GeometryOptions|Relations|Legend" version="3.40.13-Bratislava">
  <pipe-data-defined-properties>
    <Option type="Map">
      <Option type="QString" name="name" value=""/>
      <Option name="properties"/>
      <Option type="QString" name="type" value="collection"/>
    </Option>
  </pipe-data-defined-properties>
  <pipe>
    <provider>
      <resampling enabled="false" maxOversampling="2" zoomedInResamplingMethod="nearestNeighbour" zoomedOutResamplingMethod="nearestNeighbour"/>
    </provider>
    <rasterrenderer type="singlebandpseudocolor" nodataColor="" opacity="1" alphaBand="-1" band="1" classificationMin="1" classificationMax="1500">
      <rasterTransparency/>
      <minMaxOrigin>
        <limits>None</limits>
        <extent>WholeRaster</extent>
        <statAccuracy>Exact</statAccuracy>
        <cumulativeCutLower>0.02</cumulativeCutLower>
        <cumulativeCutUpper>0.98</cumulativeCutUpper>
        <stdDevFactor>2</stdDevFactor>
      </minMaxOrigin>
      <rastershader>
        <colorrampshader clip="0" labelPrecision="6" colorRampType="INTERPOLATED" classificationMode="1" minimumValue="1" maximumValue="1500">
          <colorramp type="gradient" name="[source]">
            <Option type="Map">
              <Option type="QString" name="color1" value="220,255,244,255,rgb:0.86274509803921573,1,0.95686274509803926,1"/>
              <Option type="QString" name="color2" value="204,198,201,255,rgb:0.80000000000000004,0.77647058823529413,0.78823529411764703,1"/>
              <Option type="QString" name="direction" value="ccw"/>
              <Option type="QString" name="discrete" value="0"/>
              <Option type="QString" name="rampType" value="gradient"/>
              <Option type="QString" name="spec" value="rgb"/>
              <Option type="QString" name="stops" value="0.0528846;206,255,211,255,rgb:0.80784313725490198,1,0.82745098039215681,1;rgb;ccw:0.182692;69,133,13,255,rgb:0.27058823529411763,0.52156862745098043,0.05098039215686274,1;rgb;ccw:0.300481;186,194,125,255,rgb:0.72941176470588232,0.76078431372549016,0.49019607843137253,1;rgb;ccw:0.432692;223,194,125,255,rgb:0.87450980392156863,0.76078431372549016,0.49019607843137253,1;rgb;ccw:0.539663;202,117,32,255,rgb:0.792156862745098,0.45882352941176469,0.12549019607843137,1;rgb;ccw:0.691106;125,72,19,255,rgb:0.49019607843137253,0.28235294117647058,0.07450980392156863,1;rgb;ccw:0.870192;148,142,144,255,rgb:0.58039215686274515,0.55686274509803924,0.56470588235294117,1;rgb;ccw"/>
            </Option>
          </colorramp>
          <item label="1.000000" alpha="255" value="1" color="#dcfff4"/>
          <item label="80.274015" alpha="255" value="80.2740154" color="#ceffd3"/>
          <item label="274.855308" alpha="255" value="274.855308" color="#45850d"/>
          <item label="451.421019" alpha="255" value="451.421019" color="#bac27d"/>
          <item label="649.605308" alpha="255" value="649.605308" color="#dfc27d"/>
          <item label="809.954837" alpha="255" value="809.954837" color="#ca7520"/>
          <item label="1036.967894" alpha="255" value="1036.967894" color="#7d4813"/>
          <item label="1305.417808" alpha="255" value="1305.417808" color="#948e90"/>
          <item label="1500.000000" alpha="255" value="1500" color="#ccc6c9"/>
          <rampLegendSettings minimumLabel="" prefix="" useContinuousLegend="1" maximumLabel="" suffix="" orientation="2" direction="0">
            <numericFormat id="basic">
              <Option type="Map">
                <Option type="invalid" name="decimal_separator"/>
                <Option type="int" name="decimals" value="6"/>
                <Option type="int" name="rounding_type" value="0"/>
                <Option type="bool" name="show_plus" value="false"/>
                <Option type="bool" name="show_thousand_separator" value="true"/>
                <Option type="bool" name="show_trailing_zeros" value="false"/>
                <Option type="invalid" name="thousand_separator"/>
              </Option>
            </numericFormat>
          </rampLegendSettings>
        </colorrampshader>
      </rastershader>
    </rasterrenderer>
    <brightnesscontrast brightness="0" gamma="1" contrast="0"/>
    <huesaturation grayscaleMode="0" colorizeGreen="128" invertColors="0" saturation="0" colorizeOn="0" colorizeRed="255" colorizeBlue="128" colorizeStrength="100"/>
    <rasterresampler maxOversampling="2"/>
    <resamplingStage>resamplingFilter</resamplingStage>
  </pipe>
  <blendMode>0</blendMode>
</qgis>
