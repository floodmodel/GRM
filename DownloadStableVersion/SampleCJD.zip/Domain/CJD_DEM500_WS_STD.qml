<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis minScale="1e+08" autoRefreshMode="Disabled" maxScale="0" version="3.40.13-Bratislava" hasScaleBasedVisibilityFlag="0" autoRefreshTime="0" styleCategories="AllStyleCategories">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal mode="0" fetchMode="0" bandNumber="1" enabled="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation mode="RepresentsElevationSurface" zscale="1" symbology="Line" zoffset="0" enabled="0" band="1">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol name="" is_animated="0" force_rhr="0" clip_to_extent="1" frame_rate="10" type="line" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" id="{9158239b-434f-4c52-96d6-d0baa0cf6ade}" pass="0" class="SimpleLine">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="line_color" type="QString" value="190,178,151,255,rgb:0.74509803921568629,0.69803921568627447,0.59215686274509804,1"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="0.6"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol name="" is_animated="0" force_rhr="0" clip_to_extent="1" frame_rate="10" type="fill" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" id="{96f06c84-a132-416c-a147-7b76cc934d4a}" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="190,178,151,255,rgb:0.74509803921568629,0.69803921568627447,0.59215686274509804,1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1"/>
            <Option name="outline_style" type="QString" value="no"/>
            <Option name="outline_width" type="QString" value="0.26"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
  </elevation>
  <customproperties>
    <Option type="Map">
      <Option name="WMSBackgroundLayer" type="QString" value="false"/>
      <Option name="WMSPublishDataSourceUrl" type="QString" value="false"/>
      <Option name="embeddedWidgets/count" type="QString" value="0"/>
      <Option name="identify/format" type="QString" value="Value"/>
    </Option>
  </customproperties>
  <mapTip enabled="1"></mapTip>
  <pipe-data-defined-properties>
    <Option type="Map">
      <Option name="name" type="QString" value=""/>
      <Option name="properties"/>
      <Option name="type" type="QString" value="collection"/>
    </Option>
  </pipe-data-defined-properties>
  <pipe>
    <provider>
      <resampling zoomedOutResamplingMethod="nearestNeighbour" maxOversampling="2" enabled="false" zoomedInResamplingMethod="nearestNeighbour"/>
    </provider>
    <rasterrenderer alphaBand="-1" type="paletted" band="1" opacity="1" nodataColor="">
      <rasterTransparency/>
      <minMaxOrigin>
        <limits>None</limits>
        <extent>WholeRaster</extent>
        <statAccuracy>Estimated</statAccuracy>
        <cumulativeCutLower>0.02</cumulativeCutLower>
        <cumulativeCutUpper>0.98</cumulativeCutUpper>
        <stdDevFactor>2</stdDevFactor>
      </minMaxOrigin>
      <colorPalette>
        <paletteEntry color="#c1d3a6" value="100101" label="100101" alpha="255"/>
        <paletteEntry color="#d8d95d" value="100102" label="100102" alpha="255"/>
        <paletteEntry color="#cab845" value="100103" label="100103" alpha="255"/>
        <paletteEntry color="#97bc25" value="100104" label="100104" alpha="255"/>
        <paletteEntry color="#4c9fee" value="100105" label="100105" alpha="255"/>
        <paletteEntry color="#ef754d" value="100106" label="100106" alpha="255"/>
        <paletteEntry color="#83dc95" value="100107" label="100107" alpha="255"/>
        <paletteEntry color="#dc0f0f" value="100108" label="100108" alpha="255"/>
        <paletteEntry color="#ca45d9" value="100109" label="100109" alpha="255"/>
        <paletteEntry color="#e1986e" value="100110" label="100110" alpha="255"/>
        <paletteEntry color="#a24aee" value="100111" label="100111" alpha="255"/>
        <paletteEntry color="#e865c8" value="100112" label="100112" alpha="255"/>
        <paletteEntry color="#98b0b5" value="100113" label="100113" alpha="255"/>
        <paletteEntry color="#8fcba3" value="100114" label="100114" alpha="255"/>
        <paletteEntry color="#e0acd7" value="100115" label="100115" alpha="255"/>
        <paletteEntry color="#73c4e7" value="100116" label="100116" alpha="255"/>
        <paletteEntry color="#d2263d" value="100117" label="100117" alpha="255"/>
        <paletteEntry color="#d3a9d8" value="100201" label="100201" alpha="255"/>
        <paletteEntry color="#7cccbd" value="100202" label="100202" alpha="255"/>
        <paletteEntry color="#9fed8e" value="100203" label="100203" alpha="255"/>
        <paletteEntry color="#cd0eb4" value="100204" label="100204" alpha="255"/>
        <paletteEntry color="#efca64" value="100205" label="100205" alpha="255"/>
        <paletteEntry color="#abc9ad" value="100206" label="100206" alpha="255"/>
        <paletteEntry color="#aecd73" value="100207" label="100207" alpha="255"/>
        <paletteEntry color="#b445ef" value="100208" label="100208" alpha="255"/>
        <paletteEntry color="#78d4b9" value="100209" label="100209" alpha="255"/>
        <paletteEntry color="#bedc7b" value="100210" label="100210" alpha="255"/>
        <paletteEntry color="#b5efcf" value="100211" label="100211" alpha="255"/>
        <paletteEntry color="#9996eb" value="100212" label="100212" alpha="255"/>
        <paletteEntry color="#cd2751" value="100213" label="100213" alpha="255"/>
        <paletteEntry color="#de2e13" value="100301" label="100301" alpha="255"/>
        <paletteEntry color="#cd78e7" value="100302" label="100302" alpha="255"/>
        <paletteEntry color="#63cde5" value="100303" label="100303" alpha="255"/>
        <paletteEntry color="#e281b2" value="100304" label="100304" alpha="255"/>
        <paletteEntry color="#d189fc" value="100305" label="100305" alpha="255"/>
        <paletteEntry color="#a0eb82" value="100306" label="100306" alpha="255"/>
        <paletteEntry color="#e6e333" value="100307" label="100307" alpha="255"/>
        <paletteEntry color="#ce8944" value="100308" label="100308" alpha="255"/>
        <paletteEntry color="#bbc93c" value="100309" label="100309" alpha="255"/>
        <paletteEntry color="#db46d9" value="100310" label="100310" alpha="255"/>
        <paletteEntry color="#eaa93f" value="100311" label="100311" alpha="255"/>
        <paletteEntry color="#7ab1da" value="100312" label="100312" alpha="255"/>
        <paletteEntry color="#7384c9" value="100313" label="100313" alpha="255"/>
        <paletteEntry color="#2cccc2" value="100314" label="100314" alpha="255"/>
        <paletteEntry color="#82dce2" value="100315" label="100315" alpha="255"/>
        <paletteEntry color="#d33c99" value="100316" label="100316" alpha="255"/>
        <paletteEntry color="#ca5984" value="100317" label="100317" alpha="255"/>
        <paletteEntry color="#adcf3c" value="100318" label="100318" alpha="255"/>
        <paletteEntry color="#dfba20" value="100319" label="100319" alpha="255"/>
      </colorPalette>
      <colorramp name="[source]" type="randomcolors">
        <Option/>
      </colorramp>
    </rasterrenderer>
    <brightnesscontrast contrast="0" brightness="0" gamma="1"/>
    <huesaturation saturation="0" invertColors="0" grayscaleMode="0" colorizeStrength="100" colorizeBlue="128" colorizeRed="255" colorizeGreen="128" colorizeOn="0"/>
    <rasterresampler maxOversampling="2"/>
    <resamplingStage>resamplingFilter</resamplingStage>
  </pipe>
  <blendMode>0</blendMode>
</qgis>
