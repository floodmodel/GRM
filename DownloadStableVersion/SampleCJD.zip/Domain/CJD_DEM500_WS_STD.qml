<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis minScale="1e+08" styleCategories="AllStyleCategories" version="3.16.12-Hannover" hasScaleBasedVisibilityFlag="0" maxScale="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
  </flags>
  <temporal mode="0" enabled="0" fetchMode="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <customproperties>
    <property key="WMSBackgroundLayer" value="false"/>
    <property key="WMSPublishDataSourceUrl" value="false"/>
    <property key="embeddedWidgets/count" value="0"/>
    <property key="identify/format" value="Value"/>
  </customproperties>
  <pipe>
    <provider>
      <resampling zoomedOutResamplingMethod="nearestNeighbour" enabled="false" maxOversampling="2" zoomedInResamplingMethod="nearestNeighbour"/>
    </provider>
    <rasterrenderer opacity="1" band="1" type="paletted" nodataColor="" alphaBand="-1">
      <rasterTransparency/>
      <minMaxOrigin>
        <limits>None</limits>
        <extent>WholeRaster</extent>
        <statAccuracy>Estimated</statAccuracy>
        <cumulativeCutLower>0.02</cumulativeCutLower>
        <cumulativeCutUpper>0.98</cumulativeCutUpper>
        <stdDevFactor>2</stdDevFactor>
      </minMaxOrigin>
      <colorPalette>
        <paletteEntry label="100101" color="#86d376" alpha="255" value="100101"/>
        <paletteEntry label="100102" color="#5439d9" alpha="255" value="100102"/>
        <paletteEntry label="100103" color="#cab845" alpha="255" value="100103"/>
        <paletteEntry label="100104" color="#7cee2f" alpha="255" value="100104"/>
        <paletteEntry label="100105" color="#4587d8" alpha="255" value="100105"/>
        <paletteEntry label="100106" color="#ef754d" alpha="255" value="100106"/>
        <paletteEntry label="100107" color="#47dc64" alpha="255" value="100107"/>
        <paletteEntry label="100108" color="#dc0f0f" alpha="255" value="100108"/>
        <paletteEntry label="100109" color="#ca45d9" alpha="255" value="100109"/>
        <paletteEntry label="100110" color="#e1986e" alpha="255" value="100110"/>
        <paletteEntry label="100111" color="#7719c8" alpha="255" value="100111"/>
        <paletteEntry label="100112" color="#e865c8" alpha="255" value="100112"/>
        <paletteEntry label="100113" color="#6ccaa2" alpha="255" value="100113"/>
        <paletteEntry label="100114" color="#68cb89" alpha="255" value="100114"/>
        <paletteEntry label="100115" color="#27e021" alpha="255" value="100115"/>
        <paletteEntry label="100116" color="#73c4e7" alpha="255" value="100116"/>
        <paletteEntry label="100117" color="#d2263d" alpha="255" value="100117"/>
        <paletteEntry label="100201" color="#712dd8" alpha="255" value="100201"/>
        <paletteEntry label="100202" color="#2eccaf" alpha="255" value="100202"/>
        <paletteEntry label="100203" color="#90ed25" alpha="255" value="100203"/>
        <paletteEntry label="100204" color="#cd0eb4" alpha="255" value="100204"/>
        <paletteEntry label="100205" color="#efca64" alpha="255" value="100205"/>
        <paletteEntry label="100206" color="#62c96a" alpha="255" value="100206"/>
        <paletteEntry label="100207" color="#aecd73" alpha="255" value="100207"/>
        <paletteEntry label="100208" color="#b445ef" alpha="255" value="100208"/>
        <paletteEntry label="100209" color="#78d4b9" alpha="255" value="100209"/>
        <paletteEntry label="100210" color="#4753dc" alpha="255" value="100210"/>
        <paletteEntry label="100211" color="#1eef7c" alpha="255" value="100211"/>
        <paletteEntry label="100212" color="#5d58eb" alpha="255" value="100212"/>
        <paletteEntry label="100213" color="#cd2751" alpha="255" value="100213"/>
        <paletteEntry label="100301" color="#de2e13" alpha="255" value="100301"/>
        <paletteEntry label="100302" color="#cd78e7" alpha="255" value="100302"/>
        <paletteEntry label="100303" color="#63cde5" alpha="255" value="100303"/>
        <paletteEntry label="100304" color="#e281b2" alpha="255" value="100304"/>
        <paletteEntry label="100305" color="#4272d1" alpha="255" value="100305"/>
        <paletteEntry label="100306" color="#a0eb82" alpha="255" value="100306"/>
        <paletteEntry label="100307" color="#e6e333" alpha="255" value="100307"/>
        <paletteEntry label="100308" color="#ce8944" alpha="255" value="100308"/>
        <paletteEntry label="100309" color="#bbc93c" alpha="255" value="100309"/>
        <paletteEntry label="100310" color="#db46d9" alpha="255" value="100310"/>
        <paletteEntry label="100311" color="#eaa93f" alpha="255" value="100311"/>
        <paletteEntry label="100312" color="#7ab1da" alpha="255" value="100312"/>
        <paletteEntry label="100313" color="#7384c9" alpha="255" value="100313"/>
        <paletteEntry label="100314" color="#2cccc2" alpha="255" value="100314"/>
        <paletteEntry label="100315" color="#82dce2" alpha="255" value="100315"/>
        <paletteEntry label="100316" color="#d33c99" alpha="255" value="100316"/>
        <paletteEntry label="100317" color="#ca5984" alpha="255" value="100317"/>
        <paletteEntry label="100318" color="#adcf3c" alpha="255" value="100318"/>
        <paletteEntry label="100319" color="#5721df" alpha="255" value="100319"/>
      </colorPalette>
      <colorramp type="randomcolors" name="[source]"/>
    </rasterrenderer>
    <brightnesscontrast brightness="0" gamma="1" contrast="0"/>
    <huesaturation colorizeRed="255" saturation="0" colorizeOn="0" colorizeGreen="128" colorizeBlue="128" colorizeStrength="100" grayscaleMode="0"/>
    <rasterresampler maxOversampling="2"/>
    <resamplingStage>resamplingFilter</resamplingStage>
  </pipe>
  <blendMode>0</blendMode>
</qgis>
