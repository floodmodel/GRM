<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="2.18.13" minimumScale="inf" maximumScale="1e+08" hasScaleBasedVisibilityFlag="0">
  <pipe>
    <rasterrenderer opacity="1" alphaBand="0" classificationMax="8" classificationMinMaxOrigin="MinMaxFullExtentExact" band="1" classificationMin="0" type="singlebandpseudocolor">
      <rasterTransparency/>
      <rastershader>
        <colorrampshader colorRampType="EXACT" clip="0">
          <item alpha="255" value="0" label="0" color="#9b52b7"/>
          <item alpha="255" value="1" label="1" color="#90ea22"/>
          <item alpha="255" value="2" label="2" color="#2d53d0"/>
          <item alpha="255" value="3" label="3" color="#5cc031"/>
          <item alpha="255" value="4" label="4" color="#b93e40"/>
          <item alpha="255" value="5" label="5" color="#86a0e3"/>
          <item alpha="255" value="6" label="6" color="#e22f8f"/>
          <item alpha="255" value="7" label="7" color="#d24efd"/>
          <item alpha="255" value="8" label="8" color="#e9a040"/>
        </colorrampshader>
      </rastershader>
    </rasterrenderer>
    <brightnesscontrast brightness="0" contrast="0"/>
    <huesaturation colorizeGreen="128" colorizeOn="0" colorizeRed="255" colorizeBlue="128" grayscaleMode="0" saturation="0" colorizeStrength="100"/>
    <rasterresampler maxOversampling="2"/>
  </pipe>
  <blendMode>0</blendMode>
</qgis>
