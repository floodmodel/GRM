#pragma once

#include <io.h>
#include <string>
#include <filesystem>

#include "bitmap_image.hpp"
#include "cpuinfo.h"
#include "cpuinfodelegate.h"
#include "systemcommand.h"

